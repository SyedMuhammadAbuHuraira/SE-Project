﻿namespace IME
{
    partial class StudentPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            coursetab = new TabPage();
            tableLayoutPanel1 = new TableLayoutPanel();
            courseGV = new DataGridView();
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            tableLayoutPanel4 = new TableLayoutPanel();
            courseIdbox = new Guna.UI2.WinForms.Guna2ComboBox();
            tableLayoutPanel5 = new TableLayoutPanel();
            addcourse = new Button();
            viewcbutton = new Button();
            editbutton = new Button();
            rcoursesGV = new DataGridView();
            resulttab = new TabPage();
            tableLayoutPanel6 = new TableLayoutPanel();
            resultGV = new DataGridView();
            messagetab = new TabPage();
            tableLayoutPanel7 = new TableLayoutPanel();
            tableLayoutPanel8 = new TableLayoutPanel();
            tableLayoutPanel9 = new TableLayoutPanel();
            msgtext = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            sendmsgbutton = new Guna.UI2.WinForms.Guna2Button();
            textBox1 = new TextBox();
            profiletab = new TabPage();
            updatebutton = new Button();
            phonebox = new Guna.UI2.WinForms.Guna2TextBox();
            emailbox = new Guna.UI2.WinForms.Guna2TextBox();
            usernamebox = new Guna.UI2.WinForms.Guna2TextBox();
            passwordbox = new Guna.UI2.WinForms.Guna2TextBox();
            fullnamebox = new Guna.UI2.WinForms.Guna2TextBox();
            matrialtab = new TabPage();
            tableLayoutPanel10 = new TableLayoutPanel();
            cmGV = new DataGridView();
            tableLayoutPanel11 = new TableLayoutPanel();
            tableLayoutPanel12 = new TableLayoutPanel();
            label1 = new Label();
            button1 = new Button();
            courseMGV = new DataGridView();
            tabPage1 = new TabPage();
            guna2TabControl1.SuspendLayout();
            coursetab.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)courseGV).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)rcoursesGV).BeginInit();
            resulttab.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)resultGV).BeginInit();
            messagetab.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            profiletab.SuspendLayout();
            matrialtab.SuspendLayout();
            tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)cmGV).BeginInit();
            tableLayoutPanel11.SuspendLayout();
            tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)courseMGV).BeginInit();
            SuspendLayout();
            // 
            // guna2TabControl1
            // 
            guna2TabControl1.Alignment = TabAlignment.Left;
            guna2TabControl1.Controls.Add(coursetab);
            guna2TabControl1.Controls.Add(resulttab);
            guna2TabControl1.Controls.Add(messagetab);
            guna2TabControl1.Controls.Add(profiletab);
            guna2TabControl1.Controls.Add(matrialtab);
            guna2TabControl1.Controls.Add(tabPage1);
            guna2TabControl1.Dock = DockStyle.Fill;
            guna2TabControl1.ItemSize = new Size(180, 40);
            guna2TabControl1.Location = new Point(0, 0);
            guna2TabControl1.Name = "guna2TabControl1";
            guna2TabControl1.SelectedIndex = 0;
            guna2TabControl1.Size = new Size(1223, 746);
            guna2TabControl1.TabButtonHoverState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            guna2TabControl1.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonHoverState.ForeColor = Color.White;
            guna2TabControl1.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            guna2TabControl1.TabButtonIdleState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            guna2TabControl1.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.TabButtonSelectedState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonSelectedState.FillColor = Color.FromArgb(29, 37, 49);
            guna2TabControl1.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonSelectedState.ForeColor = Color.White;
            guna2TabControl1.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            guna2TabControl1.TabButtonSize = new Size(180, 40);
            guna2TabControl1.TabIndex = 0;
            guna2TabControl1.TabMenuBackColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.SelectedIndexChanged += guna2TabControl1_SelectedIndexChanged;
            // 
            // coursetab
            // 
            coursetab.Controls.Add(tableLayoutPanel1);
            coursetab.Location = new Point(184, 4);
            coursetab.Name = "coursetab";
            coursetab.Padding = new Padding(3);
            coursetab.Size = new Size(1035, 738);
            coursetab.TabIndex = 0;
            coursetab.Text = "Course Enrollment";
            coursetab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(courseGV, 0, 0);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(3, 3);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 34.1530037F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 65.84699F));
            tableLayoutPanel1.Size = new Size(1029, 732);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // courseGV
            // 
            courseGV.AllowUserToAddRows = false;
            courseGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            courseGV.Dock = DockStyle.Fill;
            courseGV.Location = new Point(3, 3);
            courseGV.Name = "courseGV";
            courseGV.RowHeadersWidth = 62;
            courseGV.RowTemplate.Height = 33;
            courseGV.Size = new Size(1023, 243);
            courseGV.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 0, 0);
            tableLayoutPanel2.Controls.Add(rcoursesGV, 0, 1);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 252);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 37.526207F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 62.473793F));
            tableLayoutPanel2.Size = new Size(1023, 477);
            tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Controls.Add(tableLayoutPanel4, 0, 0);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel5, 0, 1);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 3);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Size = new Size(1017, 173);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Controls.Add(courseIdbox, 1, 0);
            tableLayoutPanel4.Dock = DockStyle.Fill;
            tableLayoutPanel4.Location = new Point(3, 3);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(502, 80);
            tableLayoutPanel4.TabIndex = 0;
            // 
            // courseIdbox
            // 
            courseIdbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            courseIdbox.BackColor = Color.Transparent;
            courseIdbox.CustomizableEdges = customizableEdges1;
            courseIdbox.DrawMode = DrawMode.OwnerDrawFixed;
            courseIdbox.DropDownStyle = ComboBoxStyle.DropDownList;
            courseIdbox.FocusedColor = Color.FromArgb(94, 148, 255);
            courseIdbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            courseIdbox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            courseIdbox.ForeColor = Color.FromArgb(68, 88, 112);
            courseIdbox.ItemHeight = 30;
            courseIdbox.Location = new Point(254, 22);
            courseIdbox.Name = "courseIdbox";
            courseIdbox.ShadowDecoration.CustomizableEdges = customizableEdges2;
            courseIdbox.Size = new Size(245, 36);
            courseIdbox.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Controls.Add(addcourse, 0, 0);
            tableLayoutPanel5.Controls.Add(viewcbutton, 1, 0);
            tableLayoutPanel5.Controls.Add(editbutton, 0, 1);
            tableLayoutPanel5.Dock = DockStyle.Fill;
            tableLayoutPanel5.Location = new Point(3, 89);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 2;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 51.8518524F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 48.1481476F));
            tableLayoutPanel5.Size = new Size(502, 81);
            tableLayoutPanel5.TabIndex = 1;
            // 
            // addcourse
            // 
            addcourse.BackColor = Color.FromArgb(128, 255, 128);
            addcourse.Dock = DockStyle.Fill;
            addcourse.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            addcourse.Location = new Point(3, 3);
            addcourse.Name = "addcourse";
            addcourse.Size = new Size(245, 36);
            addcourse.TabIndex = 0;
            addcourse.Text = "Add Course";
            addcourse.UseVisualStyleBackColor = false;
            addcourse.Click += addcourse_Click;
            // 
            // viewcbutton
            // 
            viewcbutton.BackColor = Color.FromArgb(128, 255, 128);
            viewcbutton.Dock = DockStyle.Fill;
            viewcbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            viewcbutton.ForeColor = SystemColors.ActiveCaptionText;
            viewcbutton.Location = new Point(254, 3);
            viewcbutton.Name = "viewcbutton";
            viewcbutton.Size = new Size(245, 36);
            viewcbutton.TabIndex = 1;
            viewcbutton.Text = "View Courses";
            viewcbutton.UseVisualStyleBackColor = false;
            viewcbutton.Click += viewcbutton_Click;
            // 
            // editbutton
            // 
            editbutton.BackColor = Color.FromArgb(128, 255, 128);
            editbutton.Dock = DockStyle.Fill;
            editbutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            editbutton.Location = new Point(3, 45);
            editbutton.Name = "editbutton";
            editbutton.Size = new Size(245, 33);
            editbutton.TabIndex = 2;
            editbutton.Text = "Edit Course";
            editbutton.UseVisualStyleBackColor = false;
            editbutton.Click += editbutton_Click;
            // 
            // rcoursesGV
            // 
            rcoursesGV.AllowUserToAddRows = false;
            rcoursesGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            rcoursesGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            rcoursesGV.Dock = DockStyle.Fill;
            rcoursesGV.GridColor = Color.FromArgb(224, 224, 224);
            rcoursesGV.Location = new Point(3, 182);
            rcoursesGV.Name = "rcoursesGV";
            rcoursesGV.RowHeadersWidth = 62;
            rcoursesGV.RowTemplate.Height = 33;
            rcoursesGV.Size = new Size(1017, 292);
            rcoursesGV.TabIndex = 1;
            // 
            // resulttab
            // 
            resulttab.Controls.Add(tableLayoutPanel6);
            resulttab.Location = new Point(184, 4);
            resulttab.Name = "resulttab";
            resulttab.Padding = new Padding(3);
            resulttab.Size = new Size(1035, 738);
            resulttab.TabIndex = 1;
            resulttab.Text = "Course Result";
            resulttab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 1;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Controls.Add(resultGV, 0, 0);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(3, 3);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 2;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 45.901638F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 54.098362F));
            tableLayoutPanel6.Size = new Size(1029, 732);
            tableLayoutPanel6.TabIndex = 0;
            // 
            // resultGV
            // 
            resultGV.AllowUserToAddRows = false;
            resultGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            resultGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resultGV.Dock = DockStyle.Fill;
            resultGV.Location = new Point(3, 3);
            resultGV.Name = "resultGV";
            resultGV.RowHeadersWidth = 62;
            resultGV.RowTemplate.Height = 33;
            resultGV.Size = new Size(1023, 330);
            resultGV.TabIndex = 0;
            // 
            // messagetab
            // 
            messagetab.Controls.Add(tableLayoutPanel7);
            messagetab.Location = new Point(184, 4);
            messagetab.Name = "messagetab";
            messagetab.Size = new Size(1035, 738);
            messagetab.TabIndex = 2;
            messagetab.Text = "Message";
            messagetab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 1;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Controls.Add(tableLayoutPanel8, 0, 0);
            tableLayoutPanel7.Controls.Add(textBox1, 0, 1);
            tableLayoutPanel7.Dock = DockStyle.Fill;
            tableLayoutPanel7.Location = new Point(0, 0);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 2;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Size = new Size(1035, 738);
            tableLayoutPanel7.TabIndex = 0;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 2;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.Controls.Add(tableLayoutPanel9, 0, 0);
            tableLayoutPanel8.Dock = DockStyle.Fill;
            tableLayoutPanel8.Location = new Point(3, 3);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 2;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.Size = new Size(1029, 363);
            tableLayoutPanel8.TabIndex = 0;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.ColumnCount = 2;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Controls.Add(msgtext, 1, 0);
            tableLayoutPanel9.Controls.Add(guna2HtmlLabel1, 0, 0);
            tableLayoutPanel9.Controls.Add(sendmsgbutton, 1, 1);
            tableLayoutPanel9.Dock = DockStyle.Fill;
            tableLayoutPanel9.Location = new Point(3, 3);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 2;
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Size = new Size(508, 175);
            tableLayoutPanel9.TabIndex = 0;
            // 
            // msgtext
            // 
            msgtext.CustomizableEdges = customizableEdges3;
            msgtext.DefaultText = "";
            msgtext.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            msgtext.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            msgtext.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            msgtext.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            msgtext.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            msgtext.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            msgtext.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            msgtext.Location = new Point(257, 3);
            msgtext.Name = "msgtext";
            msgtext.PasswordChar = '\0';
            msgtext.PlaceholderText = "Message";
            msgtext.SelectedText = "";
            msgtext.ShadowDecoration.CustomizableEdges = customizableEdges4;
            msgtext.Size = new Size(248, 54);
            msgtext.TabIndex = 0;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel1.BackColor = Color.FromArgb(224, 224, 224);
            guna2HtmlLabel1.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Black;
            guna2HtmlLabel1.Location = new Point(3, 26);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(103, 34);
            guna2HtmlLabel1.TabIndex = 1;
            guna2HtmlLabel1.Text = "Message";
            // 
            // sendmsgbutton
            // 
            sendmsgbutton.CustomizableEdges = customizableEdges5;
            sendmsgbutton.DisabledState.BorderColor = Color.DarkGray;
            sendmsgbutton.DisabledState.CustomBorderColor = Color.DarkGray;
            sendmsgbutton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            sendmsgbutton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            sendmsgbutton.Dock = DockStyle.Fill;
            sendmsgbutton.FillColor = Color.FromArgb(128, 255, 128);
            sendmsgbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            sendmsgbutton.ForeColor = Color.White;
            sendmsgbutton.Location = new Point(257, 90);
            sendmsgbutton.Name = "sendmsgbutton";
            sendmsgbutton.ShadowDecoration.CustomizableEdges = customizableEdges6;
            sendmsgbutton.Size = new Size(248, 82);
            sendmsgbutton.TabIndex = 2;
            sendmsgbutton.Text = "Send Message";
            sendmsgbutton.Click += sendmsgbutton_Click;
            // 
            // textBox1
            // 
            textBox1.Dock = DockStyle.Fill;
            textBox1.Location = new Point(3, 372);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1029, 363);
            textBox1.TabIndex = 1;
            // 
            // profiletab
            // 
            profiletab.BackColor = Color.FromArgb(224, 224, 224);
            profiletab.Controls.Add(updatebutton);
            profiletab.Controls.Add(phonebox);
            profiletab.Controls.Add(emailbox);
            profiletab.Controls.Add(usernamebox);
            profiletab.Controls.Add(passwordbox);
            profiletab.Controls.Add(fullnamebox);
            profiletab.Location = new Point(184, 4);
            profiletab.Name = "profiletab";
            profiletab.Padding = new Padding(3);
            profiletab.Size = new Size(1035, 738);
            profiletab.TabIndex = 3;
            profiletab.Text = "My Profile";
            // 
            // updatebutton
            // 
            updatebutton.BackColor = Color.FromArgb(128, 255, 128);
            updatebutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            updatebutton.Location = new Point(378, 595);
            updatebutton.Name = "updatebutton";
            updatebutton.Size = new Size(213, 69);
            updatebutton.TabIndex = 5;
            updatebutton.Text = "Update Profile";
            updatebutton.UseVisualStyleBackColor = false;
            updatebutton.Click += updatebutton_Click;
            // 
            // phonebox
            // 
            phonebox.CustomizableEdges = customizableEdges7;
            phonebox.DefaultText = "";
            phonebox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            phonebox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            phonebox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            phonebox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            phonebox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            phonebox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            phonebox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            phonebox.Location = new Point(316, 418);
            phonebox.Name = "phonebox";
            phonebox.PasswordChar = '\0';
            phonebox.PlaceholderText = "";
            phonebox.SelectedText = "";
            phonebox.ShadowDecoration.CustomizableEdges = customizableEdges8;
            phonebox.Size = new Size(300, 54);
            phonebox.TabIndex = 4;
            // 
            // emailbox
            // 
            emailbox.CustomizableEdges = customizableEdges9;
            emailbox.DefaultText = "";
            emailbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            emailbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            emailbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            emailbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            emailbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            emailbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            emailbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            emailbox.Location = new Point(316, 323);
            emailbox.Name = "emailbox";
            emailbox.PasswordChar = '\0';
            emailbox.PlaceholderText = "";
            emailbox.SelectedText = "";
            emailbox.ShadowDecoration.CustomizableEdges = customizableEdges10;
            emailbox.Size = new Size(300, 54);
            emailbox.TabIndex = 3;
            // 
            // usernamebox
            // 
            usernamebox.CustomizableEdges = customizableEdges11;
            usernamebox.DefaultText = "";
            usernamebox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            usernamebox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            usernamebox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            usernamebox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            usernamebox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            usernamebox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            usernamebox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            usernamebox.Location = new Point(316, 236);
            usernamebox.Name = "usernamebox";
            usernamebox.PasswordChar = '\0';
            usernamebox.PlaceholderText = "";
            usernamebox.SelectedText = "";
            usernamebox.ShadowDecoration.CustomizableEdges = customizableEdges12;
            usernamebox.Size = new Size(300, 54);
            usernamebox.TabIndex = 2;
            // 
            // passwordbox
            // 
            passwordbox.CustomizableEdges = customizableEdges13;
            passwordbox.DefaultText = "";
            passwordbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            passwordbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            passwordbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            passwordbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            passwordbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            passwordbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            passwordbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            passwordbox.Location = new Point(316, 143);
            passwordbox.Name = "passwordbox";
            passwordbox.PasswordChar = '\0';
            passwordbox.PlaceholderText = "";
            passwordbox.SelectedText = "";
            passwordbox.ShadowDecoration.CustomizableEdges = customizableEdges14;
            passwordbox.Size = new Size(300, 54);
            passwordbox.TabIndex = 1;
            // 
            // fullnamebox
            // 
            fullnamebox.CustomizableEdges = customizableEdges15;
            fullnamebox.DefaultText = "";
            fullnamebox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            fullnamebox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            fullnamebox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            fullnamebox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            fullnamebox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            fullnamebox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            fullnamebox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            fullnamebox.Location = new Point(316, 57);
            fullnamebox.Name = "fullnamebox";
            fullnamebox.PasswordChar = '\0';
            fullnamebox.PlaceholderText = "";
            fullnamebox.SelectedText = "";
            fullnamebox.ShadowDecoration.CustomizableEdges = customizableEdges16;
            fullnamebox.Size = new Size(300, 54);
            fullnamebox.TabIndex = 0;
            // 
            // matrialtab
            // 
            matrialtab.Controls.Add(tableLayoutPanel10);
            matrialtab.Location = new Point(184, 4);
            matrialtab.Name = "matrialtab";
            matrialtab.Padding = new Padding(3);
            matrialtab.Size = new Size(1035, 738);
            matrialtab.TabIndex = 4;
            matrialtab.Text = "Course Matrial";
            matrialtab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.ColumnCount = 1;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.Controls.Add(cmGV, 0, 0);
            tableLayoutPanel10.Controls.Add(tableLayoutPanel11, 0, 1);
            tableLayoutPanel10.Dock = DockStyle.Fill;
            tableLayoutPanel10.Location = new Point(3, 3);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 2;
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.Size = new Size(1029, 732);
            tableLayoutPanel10.TabIndex = 0;
            // 
            // cmGV
            // 
            cmGV.AllowUserToAddRows = false;
            cmGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            cmGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            cmGV.Dock = DockStyle.Fill;
            cmGV.Location = new Point(3, 3);
            cmGV.Name = "cmGV";
            cmGV.RowHeadersWidth = 62;
            cmGV.Size = new Size(1023, 360);
            cmGV.TabIndex = 1;
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.ColumnCount = 2;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 69.30596F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30.6940365F));
            tableLayoutPanel11.Controls.Add(tableLayoutPanel12, 0, 0);
            tableLayoutPanel11.Controls.Add(courseMGV, 0, 1);
            tableLayoutPanel11.Dock = DockStyle.Fill;
            tableLayoutPanel11.Location = new Point(3, 369);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 2;
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.Size = new Size(1023, 360);
            tableLayoutPanel11.TabIndex = 2;
            // 
            // tableLayoutPanel12
            // 
            tableLayoutPanel12.ColumnCount = 2;
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.Controls.Add(label1, 0, 0);
            tableLayoutPanel12.Controls.Add(button1, 1, 1);
            tableLayoutPanel12.Dock = DockStyle.Fill;
            tableLayoutPanel12.Location = new Point(3, 3);
            tableLayoutPanel12.Name = "tableLayoutPanel12";
            tableLayoutPanel12.RowCount = 2;
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.Size = new Size(703, 174);
            tableLayoutPanel12.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(3, 30);
            label1.Name = "label1";
            label1.Size = new Size(345, 26);
            label1.TabIndex = 1;
            label1.Text = "Search By";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(128, 255, 128);
            button1.Dock = DockStyle.Fill;
            button1.Font = new Font("Times New Roman", 16F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(354, 90);
            button1.Name = "button1";
            button1.Size = new Size(346, 81);
            button1.TabIndex = 2;
            button1.Text = "Search";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // courseMGV
            // 
            courseMGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            courseMGV.Dock = DockStyle.Fill;
            courseMGV.Location = new Point(3, 183);
            courseMGV.Name = "courseMGV";
            courseMGV.RowHeadersWidth = 62;
            courseMGV.Size = new Size(703, 174);
            courseMGV.TabIndex = 1;
            // 
            // tabPage1
            // 
            tabPage1.Location = new Point(184, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Size = new Size(1035, 738);
            tabPage1.TabIndex = 5;
            tabPage1.Text = "Log Out";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // StudentPanel
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(guna2TabControl1);
            Name = "StudentPanel";
            Size = new Size(1223, 746);
            guna2TabControl1.ResumeLayout(false);
            coursetab.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)courseGV).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)rcoursesGV).EndInit();
            resulttab.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)resultGV).EndInit();
            messagetab.ResumeLayout(false);
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel7.PerformLayout();
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel9.PerformLayout();
            profiletab.ResumeLayout(false);
            matrialtab.ResumeLayout(false);
            tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)cmGV).EndInit();
            tableLayoutPanel11.ResumeLayout(false);
            tableLayoutPanel12.ResumeLayout(false);
            tableLayoutPanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)courseMGV).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private TabPage coursetab;
        private TabPage resulttab;
        private TableLayoutPanel tableLayoutPanel1;
        private DataGridView courseGV;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel4;
        private Guna.UI2.WinForms.Guna2ComboBox courseIdbox;
        private TableLayoutPanel tableLayoutPanel5;
        private Button addcourse;
        private Button viewcbutton;
        private DataGridView rcoursesGV;
        private Button editbutton;
        private TableLayoutPanel tableLayoutPanel6;
        private DataGridView resultGV;
        private TabPage messagetab;
        private TableLayoutPanel tableLayoutPanel7;
        private TableLayoutPanel tableLayoutPanel8;
        private TableLayoutPanel tableLayoutPanel9;
        private Guna.UI2.WinForms.Guna2TextBox msgtext;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private TextBox textBox1;
        private Guna.UI2.WinForms.Guna2Button sendmsgbutton;
        private TabPage profiletab;
        private Guna.UI2.WinForms.Guna2TextBox emailbox;
        private Guna.UI2.WinForms.Guna2TextBox usernamebox;
        private Guna.UI2.WinForms.Guna2TextBox passwordbox;
        private Guna.UI2.WinForms.Guna2TextBox fullnamebox;
        private Guna.UI2.WinForms.Guna2TextBox phonebox;
        private Button updatebutton;
        private TabPage matrialtab;
        private TableLayoutPanel tableLayoutPanel10;
        private DataGridView cmGV;
        private TableLayoutPanel tableLayoutPanel11;
        private TableLayoutPanel tableLayoutPanel12;
        private Label label1;
        private Button button1;
        private DataGridView courseMGV;
        private TabPage tabPage1;
    }
}
