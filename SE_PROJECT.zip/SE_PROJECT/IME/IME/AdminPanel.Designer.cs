﻿namespace IME
{
    partial class AdminPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            tabPage1 = new TabPage();
            updatebutton = new Guna.UI2.WinForms.Guna2TileButton();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            phonenumberbox = new Guna.UI2.WinForms.Guna2TextBox();
            username = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            emailBox = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            password = new Guna.UI2.WinForms.Guna2TextBox();
            name = new Guna.UI2.WinForms.Guna2TextBox();
            tabPage2 = new TabPage();
            guna2TabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            SuspendLayout();
            // 
            // guna2TabControl1
            // 
            guna2TabControl1.Alignment = TabAlignment.Left;
            guna2TabControl1.Controls.Add(tabPage1);
            guna2TabControl1.Controls.Add(tabPage2);
            guna2TabControl1.Dock = DockStyle.Fill;
            guna2TabControl1.ItemSize = new Size(180, 40);
            guna2TabControl1.Location = new Point(0, 0);
            guna2TabControl1.Name = "guna2TabControl1";
            guna2TabControl1.SelectedIndex = 0;
            guna2TabControl1.Size = new Size(1141, 693);
            guna2TabControl1.TabButtonHoverState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            guna2TabControl1.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonHoverState.ForeColor = Color.White;
            guna2TabControl1.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            guna2TabControl1.TabButtonIdleState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            guna2TabControl1.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.TabButtonSelectedState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonSelectedState.FillColor = Color.FromArgb(29, 37, 49);
            guna2TabControl1.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonSelectedState.ForeColor = Color.White;
            guna2TabControl1.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            guna2TabControl1.TabButtonSize = new Size(180, 40);
            guna2TabControl1.TabIndex = 0;
            guna2TabControl1.TabMenuBackColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.SelectedIndexChanged += guna2TabControl1_SelectedIndexChanged;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.DimGray;
            tabPage1.BorderStyle = BorderStyle.FixedSingle;
            tabPage1.Controls.Add(updatebutton);
            tabPage1.Controls.Add(guna2HtmlLabel1);
            tabPage1.Controls.Add(guna2HtmlLabel6);
            tabPage1.Controls.Add(phonenumberbox);
            tabPage1.Controls.Add(username);
            tabPage1.Controls.Add(guna2HtmlLabel5);
            tabPage1.Controls.Add(emailBox);
            tabPage1.Controls.Add(guna2HtmlLabel4);
            tabPage1.Controls.Add(guna2HtmlLabel3);
            tabPage1.Controls.Add(guna2HtmlLabel2);
            tabPage1.Controls.Add(password);
            tabPage1.Controls.Add(name);
            tabPage1.Location = new Point(184, 4);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(953, 685);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Profile";
            // 
            // updatebutton
            // 
            updatebutton.CustomBorderColor = Color.White;
            updatebutton.CustomizableEdges = customizableEdges1;
            updatebutton.DisabledState.BorderColor = Color.DarkGray;
            updatebutton.DisabledState.CustomBorderColor = Color.DarkGray;
            updatebutton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            updatebutton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            updatebutton.FillColor = Color.Transparent;
            updatebutton.FocusedColor = Color.Black;
            updatebutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            updatebutton.ForeColor = Color.Snow;
            updatebutton.Location = new Point(363, 603);
            updatebutton.Name = "updatebutton";
            updatebutton.ShadowDecoration.CustomizableEdges = customizableEdges2;
            updatebutton.Size = new Size(295, 98);
            updatebutton.TabIndex = 19;
            updatebutton.Text = "Update";
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Red;
            guna2HtmlLabel1.Location = new Point(52, 572);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(801, 25);
            guna2HtmlLabel1.TabIndex = 18;
            guna2HtmlLabel1.Text = "Note: If you want to update your personal details then simply update and click on update button";
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel6.ForeColor = Color.White;
            guna2HtmlLabel6.Location = new Point(107, 493);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(157, 28);
            guna2HtmlLabel6.TabIndex = 17;
            guna2HtmlLabel6.Text = "Phone Number";
            // 
            // phonenumberbox
            // 
            phonenumberbox.CustomizableEdges = customizableEdges3;
            phonenumberbox.DefaultText = "";
            phonenumberbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            phonenumberbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            phonenumberbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            phonenumberbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            phonenumberbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            phonenumberbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            phonenumberbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            phonenumberbox.Location = new Point(320, 461);
            phonenumberbox.Name = "phonenumberbox";
            phonenumberbox.PasswordChar = '\0';
            phonenumberbox.PlaceholderText = "";
            phonenumberbox.SelectedText = "";
            phonenumberbox.ShadowDecoration.CustomizableEdges = customizableEdges4;
            phonenumberbox.Size = new Size(358, 78);
            phonenumberbox.TabIndex = 16;
            // 
            // username
            // 
            username.CustomizableEdges = customizableEdges5;
            username.DefaultText = "";
            username.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            username.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            username.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            username.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            username.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            username.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            username.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            username.Location = new Point(320, 359);
            username.Name = "username";
            username.PasswordChar = '\0';
            username.PlaceholderText = "";
            username.SelectedText = "";
            username.ShadowDecoration.CustomizableEdges = customizableEdges6;
            username.Size = new Size(358, 78);
            username.TabIndex = 15;
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel5.ForeColor = Color.White;
            guna2HtmlLabel5.Location = new Point(107, 382);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(116, 28);
            guna2HtmlLabel5.TabIndex = 14;
            guna2HtmlLabel5.Text = "User Name";
            // 
            // emailBox
            // 
            emailBox.CustomizableEdges = customizableEdges7;
            emailBox.DefaultText = "";
            emailBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            emailBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            emailBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            emailBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            emailBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            emailBox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            emailBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            emailBox.Location = new Point(320, 259);
            emailBox.Name = "emailBox";
            emailBox.PasswordChar = '\0';
            emailBox.PlaceholderText = "";
            emailBox.SelectedText = "";
            emailBox.ShadowDecoration.CustomizableEdges = customizableEdges8;
            emailBox.Size = new Size(358, 78);
            emailBox.TabIndex = 13;
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel4.ForeColor = Color.White;
            guna2HtmlLabel4.Location = new Point(107, 286);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(64, 28);
            guna2HtmlLabel4.TabIndex = 12;
            guna2HtmlLabel4.Text = "Email";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel3.ForeColor = Color.White;
            guna2HtmlLabel3.Location = new Point(107, 186);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(101, 28);
            guna2HtmlLabel3.TabIndex = 11;
            guna2HtmlLabel3.Text = "Password";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel2.ForeColor = Color.White;
            guna2HtmlLabel2.Location = new Point(107, 99);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(62, 28);
            guna2HtmlLabel2.TabIndex = 10;
            guna2HtmlLabel2.Text = "Name";
            // 
            // password
            // 
            password.CustomizableEdges = customizableEdges9;
            password.DefaultText = "";
            password.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            password.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            password.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            password.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            password.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            password.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            password.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            password.Location = new Point(320, 159);
            password.Name = "password";
            password.PasswordChar = '\0';
            password.PlaceholderText = "";
            password.SelectedText = "";
            password.ShadowDecoration.CustomizableEdges = customizableEdges10;
            password.Size = new Size(358, 78);
            password.TabIndex = 2;
            // 
            // name
            // 
            name.CustomizableEdges = customizableEdges11;
            name.DefaultText = "";
            name.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            name.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            name.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            name.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            name.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            name.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            name.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            name.Location = new Point(320, 58);
            name.Name = "name";
            name.PasswordChar = '\0';
            name.PlaceholderText = "";
            name.SelectedText = "";
            name.ShadowDecoration.CustomizableEdges = customizableEdges12;
            name.Size = new Size(358, 78);
            name.TabIndex = 1;
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(184, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(953, 685);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Student Menu";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // AdminPanel
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(guna2TabControl1);
            Name = "AdminPanel";
            Size = new Size(1141, 693);
            guna2TabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Guna.UI2.WinForms.Guna2TextBox name;
        private Guna.UI2.WinForms.Guna2TextBox password;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2TextBox emailBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2TextBox username;
        private Guna.UI2.WinForms.Guna2TextBox phonenumberbox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TileButton updatebutton;
    }
}
