﻿namespace IME
{
    partial class Admin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges49 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges50 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges51 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges52 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges53 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges54 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges55 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges56 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            tabPage2 = new TabPage();
            tableLayoutPanel4 = new TableLayoutPanel();
            teacherGV = new DataGridView();
            tableLayoutPanel7 = new TableLayoutPanel();
            update_button1 = new Guna.UI2.WinForms.Guna2Button();
            view_button = new Guna.UI2.WinForms.Guna2Button();
            add_button = new Guna.UI2.WinForms.Guna2Button();
            delete_button = new Guna.UI2.WinForms.Guna2Button();
            add_student = new Guna.UI2.WinForms.Guna2TabControl();
            tabPage3 = new TabPage();
            tableLayoutPanel5 = new TableLayoutPanel();
            tableLayoutPanel6 = new TableLayoutPanel();
            guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            pictureBox1 = new PictureBox();
            Profile_View = new TabPage();
            guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            updatebutton = new Guna.UI2.WinForms.Guna2TileButton();
            phonenumberbox = new Guna.UI2.WinForms.Guna2TextBox();
            username = new Guna.UI2.WinForms.Guna2TextBox();
            emailBox = new Guna.UI2.WinForms.Guna2TextBox();
            password = new Guna.UI2.WinForms.Guna2TextBox();
            name = new Guna.UI2.WinForms.Guna2TextBox();
            tabPage1 = new TabPage();
            tableLayoutPanel1 = new TableLayoutPanel();
            studentGV = new Guna.UI2.WinForms.Guna2DataGridView();
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            addbutton = new Guna.UI2.WinForms.Guna2Button();
            deleteButton = new Guna.UI2.WinForms.Guna2Button();
            allstudentbutton = new Guna.UI2.WinForms.Guna2Button();
            update_Button = new Guna.UI2.WinForms.Guna2Button();
            coursetab = new TabPage();
            tableLayoutPanel8 = new TableLayoutPanel();
            tableLayoutPanel9 = new TableLayoutPanel();
            tableLayoutPanel10 = new TableLayoutPanel();
            nametext = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            tableLayoutPanel11 = new TableLayoutPanel();
            add_course = new Guna.UI2.WinForms.Guna2Button();
            viewbutton = new Button();
            deletebtn = new Button();
            updatecoursebutton = new Button();
            tableLayoutPanel12 = new TableLayoutPanel();
            activeStatus = new Guna.UI2.WinForms.Guna2ComboBox();
            label2 = new Label();
            vew_inbutton = new Button();
            courseGV = new DataGridView();
            feetab = new TabPage();
            tableLayoutPanel13 = new TableLayoutPanel();
            tableLayoutPanel14 = new TableLayoutPanel();
            feestudentGV = new DataGridView();
            feeCourseGV = new DataGridView();
            tableLayoutPanel15 = new TableLayoutPanel();
            label4 = new Label();
            label3 = new Label();
            courseIdbox = new Guna.UI2.WinForms.Guna2ComboBox();
            studentIdbox = new Guna.UI2.WinForms.Guna2ComboBox();
            tableLayoutPanel16 = new TableLayoutPanel();
            amountbox = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            label6 = new Label();
            tableLayoutPanel17 = new TableLayoutPanel();
            tableLayoutPanel18 = new TableLayoutPanel();
            feebutton = new Button();
            view_feebutton = new Button();
            updatefeebutton = new Button();
            feeGV = new DataGridView();
            salarytab = new TabPage();
            tableLayoutPanel19 = new TableLayoutPanel();
            tableLayoutPanel20 = new TableLayoutPanel();
            teachersalaryGV = new DataGridView();
            tableLayoutPanel21 = new TableLayoutPanel();
            tableLayoutPanel22 = new TableLayoutPanel();
            label8 = new Label();
            teacherIdbox = new Guna.UI2.WinForms.Guna2ComboBox();
            label7 = new Label();
            salarybox = new Guna.UI2.WinForms.Guna2TextBox();
            tableLayoutPanel23 = new TableLayoutPanel();
            salarydate = new Guna.UI2.WinForms.Guna2DateTimePicker();
            label9 = new Label();
            tableLayoutPanel24 = new TableLayoutPanel();
            tableLayoutPanel25 = new TableLayoutPanel();
            addsbutton = new Button();
            viewsalarybutton = new Button();
            updatesalarybutton = new Button();
            addedSalaryGV = new DataGridView();
            chattab = new TabPage();
            chat_tab = new Guna.UI2.WinForms.Guna2TabControl();
            tabPage4 = new TabPage();
            tableLayoutPanel26 = new TableLayoutPanel();
            studentmessageGV = new DataGridView();
            tableLayoutPanel27 = new TableLayoutPanel();
            tableLayoutPanel28 = new TableLayoutPanel();
            tableLayoutPanel29 = new TableLayoutPanel();
            studentmsgId = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            tableLayoutPanel30 = new TableLayoutPanel();
            guna2HtmlLabel9 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            sendmsgbox = new Guna.UI2.WinForms.Guna2TextBox();
            tableLayoutPanel31 = new TableLayoutPanel();
            sendmsgbutton = new Button();
            viewmsgbutton = new Button();
            textBox1 = new TextBox();
            tabPage5 = new TabPage();
            tableLayoutPanel32 = new TableLayoutPanel();
            teacherchatGV = new DataGridView();
            tableLayoutPanel33 = new TableLayoutPanel();
            tableLayoutPanel34 = new TableLayoutPanel();
            tableLayoutPanel35 = new TableLayoutPanel();
            teacherboxId = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            tableLayoutPanel36 = new TableLayoutPanel();
            messageteacher = new Guna.UI2.WinForms.Guna2TextBox();
            guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            tableLayoutPanel37 = new TableLayoutPanel();
            sendtmsgbutton = new Button();
            viewtbutton = new Button();
            teachermsgBox = new TextBox();
            tabPage6 = new TabPage();
            tabPage2.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)teacherGV).BeginInit();
            tableLayoutPanel7.SuspendLayout();
            add_student.SuspendLayout();
            tabPage3.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            Profile_View.SuspendLayout();
            tabPage1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)studentGV).BeginInit();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            coursetab.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            tableLayoutPanel10.SuspendLayout();
            tableLayoutPanel11.SuspendLayout();
            tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)courseGV).BeginInit();
            feetab.SuspendLayout();
            tableLayoutPanel13.SuspendLayout();
            tableLayoutPanel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)feestudentGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)feeCourseGV).BeginInit();
            tableLayoutPanel15.SuspendLayout();
            tableLayoutPanel16.SuspendLayout();
            tableLayoutPanel17.SuspendLayout();
            tableLayoutPanel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)feeGV).BeginInit();
            salarytab.SuspendLayout();
            tableLayoutPanel19.SuspendLayout();
            tableLayoutPanel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)teachersalaryGV).BeginInit();
            tableLayoutPanel21.SuspendLayout();
            tableLayoutPanel22.SuspendLayout();
            tableLayoutPanel23.SuspendLayout();
            tableLayoutPanel24.SuspendLayout();
            tableLayoutPanel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)addedSalaryGV).BeginInit();
            chattab.SuspendLayout();
            chat_tab.SuspendLayout();
            tabPage4.SuspendLayout();
            tableLayoutPanel26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)studentmessageGV).BeginInit();
            tableLayoutPanel27.SuspendLayout();
            tableLayoutPanel28.SuspendLayout();
            tableLayoutPanel29.SuspendLayout();
            tableLayoutPanel30.SuspendLayout();
            tableLayoutPanel31.SuspendLayout();
            tabPage5.SuspendLayout();
            tableLayoutPanel32.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)teacherchatGV).BeginInit();
            tableLayoutPanel33.SuspendLayout();
            tableLayoutPanel34.SuspendLayout();
            tableLayoutPanel35.SuspendLayout();
            tableLayoutPanel36.SuspendLayout();
            tableLayoutPanel37.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(tableLayoutPanel4);
            tabPage2.Location = new Point(184, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Size = new Size(1212, 810);
            tabPage2.TabIndex = 2;
            tabPage2.Text = "Teacher Menu";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 1;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Controls.Add(teacherGV, 0, 0);
            tableLayoutPanel4.Controls.Add(tableLayoutPanel7, 0, 1);
            tableLayoutPanel4.Dock = DockStyle.Fill;
            tableLayoutPanel4.Location = new Point(0, 0);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 2;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(1212, 810);
            tableLayoutPanel4.TabIndex = 0;
            // 
            // teacherGV
            // 
            teacherGV.AllowUserToAddRows = false;
            teacherGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            teacherGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            teacherGV.Dock = DockStyle.Fill;
            teacherGV.Location = new Point(3, 3);
            teacherGV.Name = "teacherGV";
            teacherGV.RowHeadersWidth = 62;
            teacherGV.RowTemplate.Height = 33;
            teacherGV.Size = new Size(1206, 399);
            teacherGV.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 4;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.Controls.Add(update_button1, 3, 0);
            tableLayoutPanel7.Controls.Add(view_button, 2, 0);
            tableLayoutPanel7.Controls.Add(add_button, 0, 0);
            tableLayoutPanel7.Controls.Add(delete_button, 1, 0);
            tableLayoutPanel7.Dock = DockStyle.Fill;
            tableLayoutPanel7.Location = new Point(3, 408);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 2;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 23.8095245F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 76.1904755F));
            tableLayoutPanel7.Size = new Size(1206, 399);
            tableLayoutPanel7.TabIndex = 1;
            // 
            // update_button1
            // 
            update_button1.CustomizableEdges = customizableEdges1;
            update_button1.DisabledState.BorderColor = Color.DarkGray;
            update_button1.DisabledState.CustomBorderColor = Color.DarkGray;
            update_button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            update_button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            update_button1.Dock = DockStyle.Fill;
            update_button1.FillColor = Color.FromArgb(128, 255, 128);
            update_button1.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            update_button1.ForeColor = Color.White;
            update_button1.Location = new Point(906, 3);
            update_button1.Name = "update_button1";
            update_button1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            update_button1.Size = new Size(297, 89);
            update_button1.TabIndex = 3;
            update_button1.Text = "Update Teacher ";
            update_button1.Click += update_button1_Click;
            // 
            // view_button
            // 
            view_button.CustomizableEdges = customizableEdges3;
            view_button.DisabledState.BorderColor = Color.DarkGray;
            view_button.DisabledState.CustomBorderColor = Color.DarkGray;
            view_button.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            view_button.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            view_button.Dock = DockStyle.Fill;
            view_button.FillColor = Color.FromArgb(128, 255, 128);
            view_button.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            view_button.ForeColor = Color.White;
            view_button.Location = new Point(605, 3);
            view_button.Name = "view_button";
            view_button.ShadowDecoration.CustomizableEdges = customizableEdges4;
            view_button.Size = new Size(295, 89);
            view_button.TabIndex = 2;
            view_button.Text = "View All Teacher";
            view_button.Click += view_button_Click;
            // 
            // add_button
            // 
            add_button.CustomizableEdges = customizableEdges5;
            add_button.DisabledState.BorderColor = Color.DarkGray;
            add_button.DisabledState.CustomBorderColor = Color.DarkGray;
            add_button.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            add_button.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            add_button.Dock = DockStyle.Fill;
            add_button.FillColor = Color.FromArgb(128, 255, 128);
            add_button.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            add_button.ForeColor = Color.White;
            add_button.Location = new Point(3, 3);
            add_button.Name = "add_button";
            add_button.ShadowDecoration.CustomizableEdges = customizableEdges6;
            add_button.Size = new Size(295, 89);
            add_button.TabIndex = 0;
            add_button.Text = "Add Teacher";
            add_button.Click += add_button_Click;
            // 
            // delete_button
            // 
            delete_button.CustomizableEdges = customizableEdges7;
            delete_button.DisabledState.BorderColor = Color.DarkGray;
            delete_button.DisabledState.CustomBorderColor = Color.DarkGray;
            delete_button.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            delete_button.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            delete_button.Dock = DockStyle.Fill;
            delete_button.FillColor = Color.FromArgb(128, 255, 128);
            delete_button.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            delete_button.ForeColor = Color.White;
            delete_button.Location = new Point(304, 3);
            delete_button.Name = "delete_button";
            delete_button.ShadowDecoration.CustomizableEdges = customizableEdges8;
            delete_button.Size = new Size(295, 89);
            delete_button.TabIndex = 1;
            delete_button.Text = "Delete Teacher";
            delete_button.Click += delete_button_Click;
            // 
            // add_student
            // 
            add_student.Alignment = TabAlignment.Left;
            add_student.Controls.Add(tabPage3);
            add_student.Controls.Add(Profile_View);
            add_student.Controls.Add(tabPage1);
            add_student.Controls.Add(tabPage2);
            add_student.Controls.Add(coursetab);
            add_student.Controls.Add(feetab);
            add_student.Controls.Add(salarytab);
            add_student.Controls.Add(chattab);
            add_student.Controls.Add(tabPage6);
            add_student.Dock = DockStyle.Fill;
            add_student.ItemSize = new Size(180, 40);
            add_student.Location = new Point(0, 0);
            add_student.Name = "add_student";
            add_student.SelectedIndex = 0;
            add_student.Size = new Size(1400, 818);
            add_student.TabButtonHoverState.BorderColor = Color.Empty;
            add_student.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            add_student.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            add_student.TabButtonHoverState.ForeColor = Color.White;
            add_student.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            add_student.TabButtonIdleState.BorderColor = Color.Empty;
            add_student.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            add_student.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            add_student.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            add_student.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            add_student.TabButtonSelectedState.BorderColor = Color.Empty;
            add_student.TabButtonSelectedState.FillColor = Color.FromArgb(29, 37, 49);
            add_student.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            add_student.TabButtonSelectedState.ForeColor = Color.White;
            add_student.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            add_student.TabButtonSize = new Size(180, 40);
            add_student.TabIndex = 0;
            add_student.TabMenuBackColor = Color.FromArgb(33, 42, 57);
            add_student.SelectedIndexChanged += add_student_SelectedIndexChanged;
            add_student.Click += add_student_Click_1;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(tableLayoutPanel5);
            tabPage3.Location = new Point(184, 4);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(1212, 810);
            tabPage3.TabIndex = 3;
            tabPage3.Text = "Feed";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 1;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 79.2079239F));
            tableLayoutPanel5.Controls.Add(tableLayoutPanel6, 0, 0);
            tableLayoutPanel5.Controls.Add(pictureBox1, 0, 1);
            tableLayoutPanel5.Dock = DockStyle.Fill;
            tableLayoutPanel5.Location = new Point(0, 0);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 2;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 18.02469F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 81.97531F));
            tableLayoutPanel5.Size = new Size(1212, 810);
            tableLayoutPanel5.TabIndex = 0;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.BackColor = Color.FromArgb(128, 128, 255);
            tableLayoutPanel6.ColumnCount = 1;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80.5141F));
            tableLayoutPanel6.Controls.Add(guna2HtmlLabel7, 0, 0);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(3, 3);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Size = new Size(1206, 139);
            tableLayoutPanel6.TabIndex = 0;
            // 
            // guna2HtmlLabel7
            // 
            guna2HtmlLabel7.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel7.BackColor = Color.FromArgb(224, 224, 224);
            guna2HtmlLabel7.Font = new Font("Times New Roman", 16F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel7.Location = new Point(3, 50);
            guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            guna2HtmlLabel7.Size = new Size(1200, 38);
            guna2HtmlLabel7.TabIndex = 0;
            guna2HtmlLabel7.Text = "Welcome To Institue Managment System";
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = Properties.Resources.college_management_software;
            pictureBox1.Location = new Point(3, 148);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1206, 659);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // Profile_View
            // 
            Profile_View.BackColor = Color.DimGray;
            Profile_View.Controls.Add(guna2HtmlLabel6);
            Profile_View.Controls.Add(guna2HtmlLabel5);
            Profile_View.Controls.Add(guna2HtmlLabel4);
            Profile_View.Controls.Add(guna2HtmlLabel3);
            Profile_View.Controls.Add(guna2HtmlLabel2);
            Profile_View.Controls.Add(guna2HtmlLabel1);
            Profile_View.Controls.Add(updatebutton);
            Profile_View.Controls.Add(phonenumberbox);
            Profile_View.Controls.Add(username);
            Profile_View.Controls.Add(emailBox);
            Profile_View.Controls.Add(password);
            Profile_View.Controls.Add(name);
            Profile_View.Location = new Point(184, 4);
            Profile_View.Name = "Profile_View";
            Profile_View.Padding = new Padding(3);
            Profile_View.Size = new Size(1212, 810);
            Profile_View.TabIndex = 0;
            Profile_View.Text = "Profile  View";
            Profile_View.Click += Profile_View_Click;
            // 
            // guna2HtmlLabel6
            // 
            guna2HtmlLabel6.BackColor = Color.Transparent;
            guna2HtmlLabel6.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel6.ForeColor = Color.White;
            guna2HtmlLabel6.Location = new Point(20, 373);
            guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            guna2HtmlLabel6.Size = new Size(157, 28);
            guna2HtmlLabel6.TabIndex = 13;
            guna2HtmlLabel6.Text = "Phone Number";
            // 
            // guna2HtmlLabel5
            // 
            guna2HtmlLabel5.BackColor = Color.Transparent;
            guna2HtmlLabel5.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel5.ForeColor = Color.White;
            guna2HtmlLabel5.Location = new Point(20, 290);
            guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            guna2HtmlLabel5.Size = new Size(116, 28);
            guna2HtmlLabel5.TabIndex = 12;
            guna2HtmlLabel5.Text = "User Name";
            // 
            // guna2HtmlLabel4
            // 
            guna2HtmlLabel4.BackColor = Color.Transparent;
            guna2HtmlLabel4.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel4.ForeColor = Color.White;
            guna2HtmlLabel4.Location = new Point(20, 208);
            guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            guna2HtmlLabel4.Size = new Size(64, 28);
            guna2HtmlLabel4.TabIndex = 11;
            guna2HtmlLabel4.Text = "Email";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel3.ForeColor = Color.White;
            guna2HtmlLabel3.Location = new Point(20, 127);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(101, 28);
            guna2HtmlLabel3.TabIndex = 10;
            guna2HtmlLabel3.Text = "Password";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel2.ForeColor = Color.White;
            guna2HtmlLabel2.Location = new Point(20, 58);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(62, 28);
            guna2HtmlLabel2.TabIndex = 9;
            guna2HtmlLabel2.Text = "Name";
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel1.ForeColor = Color.Red;
            guna2HtmlLabel1.Location = new Point(20, 452);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(801, 25);
            guna2HtmlLabel1.TabIndex = 8;
            guna2HtmlLabel1.Text = "Note: If you want to update your personal details then simply update and click on update button";
            // 
            // updatebutton
            // 
            updatebutton.CustomBorderColor = Color.White;
            updatebutton.CustomizableEdges = customizableEdges9;
            updatebutton.DisabledState.BorderColor = Color.DarkGray;
            updatebutton.DisabledState.CustomBorderColor = Color.DarkGray;
            updatebutton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            updatebutton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            updatebutton.FillColor = Color.Transparent;
            updatebutton.FocusedColor = Color.Black;
            updatebutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            updatebutton.ForeColor = Color.Snow;
            updatebutton.Location = new Point(293, 515);
            updatebutton.Name = "updatebutton";
            updatebutton.ShadowDecoration.CustomizableEdges = customizableEdges10;
            updatebutton.Size = new Size(295, 98);
            updatebutton.TabIndex = 7;
            updatebutton.Text = "Update";
            updatebutton.Click += updatebutton_Click;
            // 
            // phonenumberbox
            // 
            phonenumberbox.CustomizableEdges = customizableEdges11;
            phonenumberbox.DefaultText = "";
            phonenumberbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            phonenumberbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            phonenumberbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            phonenumberbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            phonenumberbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            phonenumberbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            phonenumberbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            phonenumberbox.Location = new Point(336, 373);
            phonenumberbox.Name = "phonenumberbox";
            phonenumberbox.PasswordChar = '\0';
            phonenumberbox.PlaceholderText = "";
            phonenumberbox.SelectedText = "";
            phonenumberbox.ShadowDecoration.CustomizableEdges = customizableEdges12;
            phonenumberbox.Size = new Size(358, 78);
            phonenumberbox.TabIndex = 4;
            // 
            // username
            // 
            username.CustomizableEdges = customizableEdges13;
            username.DefaultText = "";
            username.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            username.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            username.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            username.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            username.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            username.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            username.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            username.Location = new Point(336, 290);
            username.Name = "username";
            username.PasswordChar = '\0';
            username.PlaceholderText = "";
            username.SelectedText = "";
            username.ShadowDecoration.CustomizableEdges = customizableEdges14;
            username.Size = new Size(358, 78);
            username.TabIndex = 3;
            // 
            // emailBox
            // 
            emailBox.CustomizableEdges = customizableEdges15;
            emailBox.DefaultText = "";
            emailBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            emailBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            emailBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            emailBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            emailBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            emailBox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            emailBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            emailBox.Location = new Point(336, 208);
            emailBox.Name = "emailBox";
            emailBox.PasswordChar = '\0';
            emailBox.PlaceholderText = "";
            emailBox.SelectedText = "";
            emailBox.ShadowDecoration.CustomizableEdges = customizableEdges16;
            emailBox.Size = new Size(358, 78);
            emailBox.TabIndex = 2;
            // 
            // password
            // 
            password.CustomizableEdges = customizableEdges17;
            password.DefaultText = "";
            password.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            password.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            password.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            password.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            password.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            password.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            password.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            password.Location = new Point(336, 127);
            password.Name = "password";
            password.PasswordChar = '\0';
            password.PlaceholderText = "";
            password.SelectedText = "";
            password.ShadowDecoration.CustomizableEdges = customizableEdges18;
            password.Size = new Size(358, 78);
            password.TabIndex = 1;
            // 
            // name
            // 
            name.CustomizableEdges = customizableEdges19;
            name.DefaultText = "";
            name.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            name.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            name.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            name.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            name.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            name.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            name.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            name.Location = new Point(336, 40);
            name.Name = "name";
            name.PasswordChar = '\0';
            name.PlaceholderText = "";
            name.SelectedText = "";
            name.ShadowDecoration.CustomizableEdges = customizableEdges20;
            name.Size = new Size(358, 78);
            name.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(tableLayoutPanel1);
            tabPage1.Location = new Point(184, 4);
            tabPage1.Margin = new Padding(4, 5, 4, 5);
            tabPage1.Name = "tabPage1";
            tabPage1.Size = new Size(1212, 810);
            tabPage1.TabIndex = 1;
            tabPage1.Text = "Student Menu";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(studentGV, 0, 0);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 61.69872F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 38.30128F));
            tableLayoutPanel1.Size = new Size(1212, 810);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // studentGV
            // 
            studentGV.AllowUserToAddRows = false;
            studentGV.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(250, 237, 183);
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(245, 215, 95);
            dataGridViewCellStyle1.SelectionForeColor = Color.Black;
            studentGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(241, 196, 15);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(241, 196, 15);
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            studentGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            studentGV.ColumnHeadersHeight = 4;
            studentGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(251, 243, 207);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(245, 215, 95);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            studentGV.DefaultCellStyle = dataGridViewCellStyle3;
            studentGV.Dock = DockStyle.Fill;
            studentGV.GridColor = Color.FromArgb(249, 233, 170);
            studentGV.Location = new Point(3, 3);
            studentGV.Name = "studentGV";
            studentGV.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(251, 243, 207);
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.FromArgb(251, 243, 207);
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            studentGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            studentGV.RowHeadersVisible = false;
            studentGV.RowHeadersWidth = 62;
            studentGV.RowTemplate.Height = 33;
            studentGV.Size = new Size(1206, 493);
            studentGV.TabIndex = 0;
            studentGV.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.SunFlower;
            studentGV.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(250, 237, 183);
            studentGV.ThemeStyle.AlternatingRowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            studentGV.ThemeStyle.AlternatingRowsStyle.ForeColor = SystemColors.ControlText;
            studentGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.FromArgb(245, 215, 95);
            studentGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Black;
            studentGV.ThemeStyle.BackColor = Color.White;
            studentGV.ThemeStyle.GridColor = Color.FromArgb(249, 233, 170);
            studentGV.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(241, 196, 15);
            studentGV.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            studentGV.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            studentGV.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            studentGV.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            studentGV.ThemeStyle.HeaderStyle.Height = 4;
            studentGV.ThemeStyle.ReadOnly = false;
            studentGV.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(251, 243, 207);
            studentGV.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            studentGV.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            studentGV.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            studentGV.ThemeStyle.RowsStyle.Height = 33;
            studentGV.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(245, 215, 95);
            studentGV.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(4, 504);
            tableLayoutPanel2.Margin = new Padding(4, 5, 4, 5);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Size = new Size(1204, 301);
            tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 4;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel3.Controls.Add(addbutton, 0, 0);
            tableLayoutPanel3.Controls.Add(deleteButton, 1, 0);
            tableLayoutPanel3.Controls.Add(allstudentbutton, 2, 0);
            tableLayoutPanel3.Controls.Add(update_Button, 3, 0);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(4, 5);
            tableLayoutPanel3.Margin = new Padding(4, 5, 4, 5);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.Size = new Size(1196, 140);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // addbutton
            // 
            addbutton.CustomizableEdges = customizableEdges21;
            addbutton.DisabledState.BorderColor = Color.DarkGray;
            addbutton.DisabledState.CustomBorderColor = Color.DarkGray;
            addbutton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            addbutton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            addbutton.Dock = DockStyle.Fill;
            addbutton.FillColor = Color.FromArgb(128, 255, 128);
            addbutton.FocusedColor = Color.Silver;
            addbutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            addbutton.ForeColor = Color.Black;
            addbutton.Location = new Point(4, 5);
            addbutton.Margin = new Padding(4, 5, 4, 5);
            addbutton.Name = "addbutton";
            addbutton.ShadowDecoration.CustomizableEdges = customizableEdges22;
            addbutton.Size = new Size(291, 130);
            addbutton.TabIndex = 0;
            addbutton.Text = "Add Student";
            addbutton.Click += addbutton_Click;
            // 
            // deleteButton
            // 
            deleteButton.CustomizableEdges = customizableEdges23;
            deleteButton.DisabledState.BorderColor = Color.DarkGray;
            deleteButton.DisabledState.CustomBorderColor = Color.DarkGray;
            deleteButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            deleteButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            deleteButton.Dock = DockStyle.Fill;
            deleteButton.FillColor = Color.FromArgb(128, 255, 128);
            deleteButton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            deleteButton.ForeColor = Color.Black;
            deleteButton.Location = new Point(303, 5);
            deleteButton.Margin = new Padding(4, 5, 4, 5);
            deleteButton.Name = "deleteButton";
            deleteButton.ShadowDecoration.CustomizableEdges = customizableEdges24;
            deleteButton.Size = new Size(291, 130);
            deleteButton.TabIndex = 1;
            deleteButton.Text = "Delete Student";
            deleteButton.Click += deleteButton_Click;
            // 
            // allstudentbutton
            // 
            allstudentbutton.CustomizableEdges = customizableEdges25;
            allstudentbutton.DisabledState.BorderColor = Color.DarkGray;
            allstudentbutton.DisabledState.CustomBorderColor = Color.DarkGray;
            allstudentbutton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            allstudentbutton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            allstudentbutton.Dock = DockStyle.Fill;
            allstudentbutton.FillColor = Color.FromArgb(128, 255, 128);
            allstudentbutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            allstudentbutton.ForeColor = Color.Black;
            allstudentbutton.Location = new Point(602, 5);
            allstudentbutton.Margin = new Padding(4, 5, 4, 5);
            allstudentbutton.Name = "allstudentbutton";
            allstudentbutton.ShadowDecoration.CustomizableEdges = customizableEdges26;
            allstudentbutton.Size = new Size(291, 130);
            allstudentbutton.TabIndex = 2;
            allstudentbutton.Text = "View All Student";
            allstudentbutton.Click += allstudentbutton_Click;
            // 
            // update_Button
            // 
            update_Button.CustomizableEdges = customizableEdges27;
            update_Button.DisabledState.BorderColor = Color.DarkGray;
            update_Button.DisabledState.CustomBorderColor = Color.DarkGray;
            update_Button.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            update_Button.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            update_Button.Dock = DockStyle.Fill;
            update_Button.FillColor = Color.FromArgb(128, 255, 128);
            update_Button.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            update_Button.ForeColor = Color.Black;
            update_Button.Location = new Point(901, 5);
            update_Button.Margin = new Padding(4, 5, 4, 5);
            update_Button.Name = "update_Button";
            update_Button.ShadowDecoration.CustomizableEdges = customizableEdges28;
            update_Button.Size = new Size(291, 130);
            update_Button.TabIndex = 3;
            update_Button.Text = "Update Student";
            update_Button.Click += update_Button_Click;
            // 
            // coursetab
            // 
            coursetab.Controls.Add(tableLayoutPanel8);
            coursetab.Location = new Point(184, 4);
            coursetab.Name = "coursetab";
            coursetab.Padding = new Padding(3);
            coursetab.Size = new Size(1212, 810);
            coursetab.TabIndex = 4;
            coursetab.Text = "Course Menu";
            coursetab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 1;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.Controls.Add(tableLayoutPanel9, 0, 0);
            tableLayoutPanel8.Dock = DockStyle.Fill;
            tableLayoutPanel8.Location = new Point(3, 3);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 2;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.Size = new Size(1206, 804);
            tableLayoutPanel8.TabIndex = 0;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.ColumnCount = 1;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Controls.Add(tableLayoutPanel10, 0, 0);
            tableLayoutPanel9.Controls.Add(courseGV, 0, 1);
            tableLayoutPanel9.Dock = DockStyle.Fill;
            tableLayoutPanel9.Location = new Point(3, 3);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 2;
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Size = new Size(1200, 396);
            tableLayoutPanel9.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.ColumnCount = 2;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.Controls.Add(nametext, 1, 0);
            tableLayoutPanel10.Controls.Add(label1, 0, 0);
            tableLayoutPanel10.Controls.Add(tableLayoutPanel11, 0, 1);
            tableLayoutPanel10.Controls.Add(tableLayoutPanel12, 1, 1);
            tableLayoutPanel10.Dock = DockStyle.Fill;
            tableLayoutPanel10.Location = new Point(3, 3);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 2;
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.Size = new Size(1194, 192);
            tableLayoutPanel10.TabIndex = 0;
            // 
            // nametext
            // 
            nametext.Anchor = AnchorStyles.Left;
            nametext.CustomizableEdges = customizableEdges29;
            nametext.DefaultText = "";
            nametext.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            nametext.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            nametext.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            nametext.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            nametext.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            nametext.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            nametext.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            nametext.Location = new Point(600, 21);
            nametext.Name = "nametext";
            nametext.PasswordChar = '\0';
            nametext.PlaceholderText = "Course Name";
            nametext.SelectedText = "";
            nametext.ShadowDecoration.CustomizableEdges = customizableEdges30;
            nametext.Size = new Size(314, 54);
            nametext.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Right;
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.System;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(444, 35);
            label1.Name = "label1";
            label1.Size = new Size(150, 26);
            label1.TabIndex = 1;
            label1.Text = "Course Name";
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.ColumnCount = 2;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.Controls.Add(add_course, 0, 0);
            tableLayoutPanel11.Controls.Add(viewbutton, 1, 0);
            tableLayoutPanel11.Controls.Add(deletebtn, 0, 1);
            tableLayoutPanel11.Controls.Add(updatecoursebutton, 1, 1);
            tableLayoutPanel11.Dock = DockStyle.Fill;
            tableLayoutPanel11.Location = new Point(3, 99);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 2;
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.Size = new Size(591, 90);
            tableLayoutPanel11.TabIndex = 2;
            // 
            // add_course
            // 
            add_course.CustomizableEdges = customizableEdges31;
            add_course.DisabledState.BorderColor = Color.DarkGray;
            add_course.DisabledState.CustomBorderColor = Color.DarkGray;
            add_course.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            add_course.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            add_course.Dock = DockStyle.Fill;
            add_course.FillColor = Color.FromArgb(128, 255, 128);
            add_course.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            add_course.ForeColor = Color.White;
            add_course.Location = new Point(3, 3);
            add_course.Name = "add_course";
            add_course.ShadowDecoration.CustomizableEdges = customizableEdges32;
            add_course.Size = new Size(289, 39);
            add_course.TabIndex = 0;
            add_course.Text = "Add Course";
            add_course.Click += add_course_Click;
            // 
            // viewbutton
            // 
            viewbutton.BackColor = Color.FromArgb(128, 255, 128);
            viewbutton.Dock = DockStyle.Fill;
            viewbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            viewbutton.ForeColor = Color.White;
            viewbutton.Location = new Point(298, 3);
            viewbutton.Name = "viewbutton";
            viewbutton.Size = new Size(290, 39);
            viewbutton.TabIndex = 1;
            viewbutton.Text = "View All Course";
            viewbutton.UseVisualStyleBackColor = false;
            viewbutton.Click += viewbutton_Click;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.FromArgb(128, 255, 128);
            deletebtn.Dock = DockStyle.Fill;
            deletebtn.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            deletebtn.ForeColor = Color.White;
            deletebtn.Location = new Point(3, 48);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(289, 39);
            deletebtn.TabIndex = 2;
            deletebtn.Text = "Delete Course";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // updatecoursebutton
            // 
            updatecoursebutton.BackColor = Color.FromArgb(128, 255, 128);
            updatecoursebutton.Dock = DockStyle.Fill;
            updatecoursebutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            updatecoursebutton.ForeColor = Color.White;
            updatecoursebutton.Location = new Point(298, 48);
            updatecoursebutton.Name = "updatecoursebutton";
            updatecoursebutton.Size = new Size(290, 39);
            updatecoursebutton.TabIndex = 3;
            updatecoursebutton.Text = "Update Course";
            updatecoursebutton.UseVisualStyleBackColor = false;
            updatecoursebutton.Click += updatecoursebutton_Click;
            // 
            // tableLayoutPanel12
            // 
            tableLayoutPanel12.ColumnCount = 2;
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.Controls.Add(activeStatus, 1, 0);
            tableLayoutPanel12.Controls.Add(label2, 0, 0);
            tableLayoutPanel12.Controls.Add(vew_inbutton, 1, 1);
            tableLayoutPanel12.Dock = DockStyle.Fill;
            tableLayoutPanel12.Location = new Point(600, 99);
            tableLayoutPanel12.Name = "tableLayoutPanel12";
            tableLayoutPanel12.RowCount = 2;
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel12.Size = new Size(591, 90);
            tableLayoutPanel12.TabIndex = 3;
            // 
            // activeStatus
            // 
            activeStatus.BackColor = Color.Transparent;
            activeStatus.CustomizableEdges = customizableEdges33;
            activeStatus.DrawMode = DrawMode.OwnerDrawFixed;
            activeStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            activeStatus.FocusedColor = Color.FromArgb(94, 148, 255);
            activeStatus.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            activeStatus.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            activeStatus.ForeColor = Color.FromArgb(68, 88, 112);
            activeStatus.ItemHeight = 30;
            activeStatus.Items.AddRange(new object[] { "0", "1" });
            activeStatus.Location = new Point(298, 3);
            activeStatus.Name = "activeStatus";
            activeStatus.ShadowDecoration.CustomizableEdges = customizableEdges34;
            activeStatus.Size = new Size(210, 36);
            activeStatus.TabIndex = 4;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(97, 9);
            label2.Name = "label2";
            label2.Size = new Size(195, 26);
            label2.TabIndex = 5;
            label2.Text = "In-Active Courses";
            // 
            // vew_inbutton
            // 
            vew_inbutton.BackColor = Color.FromArgb(128, 255, 128);
            vew_inbutton.Dock = DockStyle.Fill;
            vew_inbutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            vew_inbutton.ForeColor = Color.White;
            vew_inbutton.Location = new Point(298, 48);
            vew_inbutton.Name = "vew_inbutton";
            vew_inbutton.Size = new Size(290, 39);
            vew_inbutton.TabIndex = 6;
            vew_inbutton.Text = "View In-Active Courses";
            vew_inbutton.UseVisualStyleBackColor = false;
            vew_inbutton.Click += vew_inbutton_Click;
            // 
            // courseGV
            // 
            courseGV.AllowUserToAddRows = false;
            courseGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            courseGV.BorderStyle = BorderStyle.Fixed3D;
            courseGV.CellBorderStyle = DataGridViewCellBorderStyle.Sunken;
            courseGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            courseGV.Dock = DockStyle.Fill;
            courseGV.Location = new Point(3, 201);
            courseGV.Name = "courseGV";
            courseGV.RowHeadersWidth = 62;
            courseGV.RowTemplate.Height = 33;
            courseGV.Size = new Size(1194, 192);
            courseGV.TabIndex = 1;
            // 
            // feetab
            // 
            feetab.Controls.Add(tableLayoutPanel13);
            feetab.Location = new Point(184, 4);
            feetab.Name = "feetab";
            feetab.Size = new Size(1212, 810);
            feetab.TabIndex = 5;
            feetab.Text = "Fee Management";
            feetab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel13
            // 
            tableLayoutPanel13.ColumnCount = 1;
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel13.Controls.Add(tableLayoutPanel14, 0, 0);
            tableLayoutPanel13.Controls.Add(tableLayoutPanel17, 0, 1);
            tableLayoutPanel13.Dock = DockStyle.Fill;
            tableLayoutPanel13.Location = new Point(0, 0);
            tableLayoutPanel13.Name = "tableLayoutPanel13";
            tableLayoutPanel13.RowCount = 2;
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 60.6172829F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 39.3827171F));
            tableLayoutPanel13.Size = new Size(1212, 810);
            tableLayoutPanel13.TabIndex = 0;
            // 
            // tableLayoutPanel14
            // 
            tableLayoutPanel14.ColumnCount = 2;
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel14.Controls.Add(feestudentGV, 0, 0);
            tableLayoutPanel14.Controls.Add(feeCourseGV, 1, 0);
            tableLayoutPanel14.Controls.Add(tableLayoutPanel15, 0, 1);
            tableLayoutPanel14.Controls.Add(tableLayoutPanel16, 1, 1);
            tableLayoutPanel14.Dock = DockStyle.Fill;
            tableLayoutPanel14.Location = new Point(3, 3);
            tableLayoutPanel14.Name = "tableLayoutPanel14";
            tableLayoutPanel14.RowCount = 2;
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel14.Size = new Size(1206, 485);
            tableLayoutPanel14.TabIndex = 0;
            // 
            // feestudentGV
            // 
            feestudentGV.AllowUserToAddRows = false;
            feestudentGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            feestudentGV.Dock = DockStyle.Fill;
            feestudentGV.Location = new Point(3, 3);
            feestudentGV.Name = "feestudentGV";
            feestudentGV.ReadOnly = true;
            feestudentGV.RowHeadersWidth = 62;
            feestudentGV.RowTemplate.Height = 33;
            feestudentGV.Size = new Size(597, 236);
            feestudentGV.TabIndex = 0;
            // 
            // feeCourseGV
            // 
            feeCourseGV.AllowUserToAddRows = false;
            feeCourseGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            feeCourseGV.Dock = DockStyle.Fill;
            feeCourseGV.Location = new Point(606, 3);
            feeCourseGV.Name = "feeCourseGV";
            feeCourseGV.RowHeadersWidth = 62;
            feeCourseGV.RowTemplate.Height = 33;
            feeCourseGV.Size = new Size(597, 236);
            feeCourseGV.TabIndex = 1;
            // 
            // tableLayoutPanel15
            // 
            tableLayoutPanel15.ColumnCount = 2;
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel15.Controls.Add(label4, 0, 1);
            tableLayoutPanel15.Controls.Add(label3, 0, 0);
            tableLayoutPanel15.Controls.Add(courseIdbox, 1, 0);
            tableLayoutPanel15.Controls.Add(studentIdbox, 1, 1);
            tableLayoutPanel15.Dock = DockStyle.Fill;
            tableLayoutPanel15.Location = new Point(3, 245);
            tableLayoutPanel15.Name = "tableLayoutPanel15";
            tableLayoutPanel15.RowCount = 2;
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel15.Size = new Size(597, 237);
            tableLayoutPanel15.TabIndex = 2;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label4.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(3, 161);
            label4.Name = "label4";
            label4.Size = new Size(292, 32);
            label4.TabIndex = 3;
            label4.Text = "Student Id";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(3, 43);
            label3.Name = "label3";
            label3.Size = new Size(292, 32);
            label3.TabIndex = 1;
            label3.Text = "Course Id";
            // 
            // courseIdbox
            // 
            courseIdbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            courseIdbox.BackColor = Color.Transparent;
            courseIdbox.CustomizableEdges = customizableEdges35;
            courseIdbox.DrawMode = DrawMode.OwnerDrawFixed;
            courseIdbox.DropDownStyle = ComboBoxStyle.DropDownList;
            courseIdbox.FocusedColor = Color.FromArgb(94, 148, 255);
            courseIdbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            courseIdbox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            courseIdbox.ForeColor = Color.FromArgb(68, 88, 112);
            courseIdbox.ItemHeight = 30;
            courseIdbox.Location = new Point(301, 41);
            courseIdbox.Name = "courseIdbox";
            courseIdbox.ShadowDecoration.CustomizableEdges = customizableEdges36;
            courseIdbox.Size = new Size(293, 36);
            courseIdbox.TabIndex = 4;
            // 
            // studentIdbox
            // 
            studentIdbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            studentIdbox.BackColor = Color.Transparent;
            studentIdbox.CustomizableEdges = customizableEdges37;
            studentIdbox.DrawMode = DrawMode.OwnerDrawFixed;
            studentIdbox.DropDownStyle = ComboBoxStyle.DropDownList;
            studentIdbox.FocusedColor = Color.FromArgb(94, 148, 255);
            studentIdbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            studentIdbox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            studentIdbox.ForeColor = Color.FromArgb(68, 88, 112);
            studentIdbox.ItemHeight = 30;
            studentIdbox.Location = new Point(301, 159);
            studentIdbox.Name = "studentIdbox";
            studentIdbox.ShadowDecoration.CustomizableEdges = customizableEdges38;
            studentIdbox.Size = new Size(293, 36);
            studentIdbox.TabIndex = 5;
            // 
            // tableLayoutPanel16
            // 
            tableLayoutPanel16.ColumnCount = 2;
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.Controls.Add(amountbox, 1, 0);
            tableLayoutPanel16.Controls.Add(label5, 0, 0);
            tableLayoutPanel16.Controls.Add(DateTimePicker1, 1, 1);
            tableLayoutPanel16.Controls.Add(label6, 0, 1);
            tableLayoutPanel16.Dock = DockStyle.Fill;
            tableLayoutPanel16.Location = new Point(606, 245);
            tableLayoutPanel16.Name = "tableLayoutPanel16";
            tableLayoutPanel16.RowCount = 2;
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.Size = new Size(597, 237);
            tableLayoutPanel16.TabIndex = 3;
            // 
            // amountbox
            // 
            amountbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            amountbox.CustomizableEdges = customizableEdges39;
            amountbox.DefaultText = "";
            amountbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            amountbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            amountbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            amountbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            amountbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            amountbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            amountbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            amountbox.Location = new Point(301, 32);
            amountbox.Name = "amountbox";
            amountbox.PasswordChar = '\0';
            amountbox.PlaceholderText = "Course Fee";
            amountbox.SelectedText = "";
            amountbox.ShadowDecoration.CustomizableEdges = customizableEdges40;
            amountbox.Size = new Size(293, 54);
            amountbox.TabIndex = 0;
            amountbox.Validating += amountbox_Validating;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(3, 43);
            label5.Name = "label5";
            label5.Size = new Size(292, 32);
            label5.TabIndex = 1;
            label5.Text = "Course Fee";
            // 
            // DateTimePicker1
            // 
            DateTimePicker1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            DateTimePicker1.Checked = true;
            DateTimePicker1.CustomizableEdges = customizableEdges41;
            DateTimePicker1.FillColor = Color.FromArgb(224, 224, 224);
            DateTimePicker1.Font = new Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point);
            DateTimePicker1.Format = DateTimePickerFormat.Long;
            DateTimePicker1.Location = new Point(301, 150);
            DateTimePicker1.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            DateTimePicker1.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            DateTimePicker1.Name = "DateTimePicker1";
            DateTimePicker1.ShadowDecoration.CustomizableEdges = customizableEdges42;
            DateTimePicker1.Size = new Size(293, 54);
            DateTimePicker1.TabIndex = 2;
            DateTimePicker1.Value = new DateTime(2023, 11, 27, 18, 48, 13, 345);
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(3, 161);
            label6.Name = "label6";
            label6.Size = new Size(292, 32);
            label6.TabIndex = 3;
            label6.Text = "Due Date";
            // 
            // tableLayoutPanel17
            // 
            tableLayoutPanel17.ColumnCount = 1;
            tableLayoutPanel17.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel17.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel17.Controls.Add(tableLayoutPanel18, 0, 0);
            tableLayoutPanel17.Controls.Add(feeGV, 0, 1);
            tableLayoutPanel17.Dock = DockStyle.Fill;
            tableLayoutPanel17.Location = new Point(3, 494);
            tableLayoutPanel17.Name = "tableLayoutPanel17";
            tableLayoutPanel17.RowCount = 2;
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Percent, 29.392971F));
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Percent, 70.6070251F));
            tableLayoutPanel17.Size = new Size(1206, 313);
            tableLayoutPanel17.TabIndex = 1;
            // 
            // tableLayoutPanel18
            // 
            tableLayoutPanel18.ColumnCount = 4;
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.Controls.Add(feebutton, 0, 0);
            tableLayoutPanel18.Controls.Add(view_feebutton, 1, 0);
            tableLayoutPanel18.Controls.Add(updatefeebutton, 2, 0);
            tableLayoutPanel18.Dock = DockStyle.Fill;
            tableLayoutPanel18.Location = new Point(3, 3);
            tableLayoutPanel18.Name = "tableLayoutPanel18";
            tableLayoutPanel18.RowCount = 1;
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel18.Size = new Size(1200, 86);
            tableLayoutPanel18.TabIndex = 0;
            // 
            // feebutton
            // 
            feebutton.BackColor = Color.FromArgb(128, 255, 128);
            feebutton.Dock = DockStyle.Fill;
            feebutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            feebutton.ForeColor = Color.White;
            feebutton.Location = new Point(3, 3);
            feebutton.Name = "feebutton";
            feebutton.Size = new Size(294, 80);
            feebutton.TabIndex = 0;
            feebutton.Text = "Add Fee";
            feebutton.UseVisualStyleBackColor = false;
            feebutton.Click += feebutton_Click;
            // 
            // view_feebutton
            // 
            view_feebutton.BackColor = Color.FromArgb(128, 255, 128);
            view_feebutton.Dock = DockStyle.Fill;
            view_feebutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            view_feebutton.ForeColor = Color.White;
            view_feebutton.Location = new Point(303, 3);
            view_feebutton.Name = "view_feebutton";
            view_feebutton.Size = new Size(294, 80);
            view_feebutton.TabIndex = 1;
            view_feebutton.Text = "View Details";
            view_feebutton.UseVisualStyleBackColor = false;
            view_feebutton.Click += view_feebutton_Click;
            // 
            // updatefeebutton
            // 
            updatefeebutton.BackColor = Color.FromArgb(128, 255, 128);
            updatefeebutton.Dock = DockStyle.Fill;
            updatefeebutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            updatefeebutton.ForeColor = Color.White;
            updatefeebutton.Location = new Point(603, 3);
            updatefeebutton.Name = "updatefeebutton";
            updatefeebutton.Size = new Size(294, 80);
            updatefeebutton.TabIndex = 2;
            updatefeebutton.Text = "Update Fee ";
            updatefeebutton.UseVisualStyleBackColor = false;
            updatefeebutton.Click += updatefeebutton_Click;
            // 
            // feeGV
            // 
            feeGV.AllowUserToAddRows = false;
            feeGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            feeGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            feeGV.Dock = DockStyle.Fill;
            feeGV.Location = new Point(3, 95);
            feeGV.Name = "feeGV";
            feeGV.RowHeadersWidth = 62;
            feeGV.RowTemplate.Height = 33;
            feeGV.Size = new Size(1200, 215);
            feeGV.TabIndex = 1;
            // 
            // salarytab
            // 
            salarytab.Controls.Add(tableLayoutPanel19);
            salarytab.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point);
            salarytab.Location = new Point(184, 4);
            salarytab.Name = "salarytab";
            salarytab.Size = new Size(1212, 810);
            salarytab.TabIndex = 6;
            salarytab.Text = "Salary Management";
            salarytab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel19
            // 
            tableLayoutPanel19.ColumnCount = 1;
            tableLayoutPanel19.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel19.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel19.Controls.Add(tableLayoutPanel20, 0, 0);
            tableLayoutPanel19.Controls.Add(tableLayoutPanel24, 0, 1);
            tableLayoutPanel19.Dock = DockStyle.Fill;
            tableLayoutPanel19.Location = new Point(0, 0);
            tableLayoutPanel19.Name = "tableLayoutPanel19";
            tableLayoutPanel19.RowCount = 2;
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 56.17284F));
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 43.82716F));
            tableLayoutPanel19.Size = new Size(1212, 810);
            tableLayoutPanel19.TabIndex = 0;
            // 
            // tableLayoutPanel20
            // 
            tableLayoutPanel20.ColumnCount = 1;
            tableLayoutPanel20.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel20.Controls.Add(teachersalaryGV, 0, 0);
            tableLayoutPanel20.Controls.Add(tableLayoutPanel21, 0, 1);
            tableLayoutPanel20.Dock = DockStyle.Fill;
            tableLayoutPanel20.Location = new Point(3, 3);
            tableLayoutPanel20.Name = "tableLayoutPanel20";
            tableLayoutPanel20.RowCount = 2;
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 46.5478859F));
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 53.4521141F));
            tableLayoutPanel20.Size = new Size(1206, 449);
            tableLayoutPanel20.TabIndex = 1;
            // 
            // teachersalaryGV
            // 
            teachersalaryGV.AllowUserToAddRows = false;
            teachersalaryGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            teachersalaryGV.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            teachersalaryGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            teachersalaryGV.Dock = DockStyle.Fill;
            teachersalaryGV.Location = new Point(3, 3);
            teachersalaryGV.Name = "teachersalaryGV";
            teachersalaryGV.RowHeadersWidth = 62;
            teachersalaryGV.RowTemplate.Height = 33;
            teachersalaryGV.Size = new Size(1200, 203);
            teachersalaryGV.TabIndex = 0;
            // 
            // tableLayoutPanel21
            // 
            tableLayoutPanel21.ColumnCount = 2;
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel21.Controls.Add(tableLayoutPanel22, 0, 0);
            tableLayoutPanel21.Controls.Add(tableLayoutPanel23, 1, 0);
            tableLayoutPanel21.Dock = DockStyle.Fill;
            tableLayoutPanel21.Location = new Point(3, 212);
            tableLayoutPanel21.Name = "tableLayoutPanel21";
            tableLayoutPanel21.RowCount = 1;
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel21.Size = new Size(1200, 234);
            tableLayoutPanel21.TabIndex = 1;
            // 
            // tableLayoutPanel22
            // 
            tableLayoutPanel22.ColumnCount = 2;
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel22.Controls.Add(label8, 0, 1);
            tableLayoutPanel22.Controls.Add(teacherIdbox, 1, 0);
            tableLayoutPanel22.Controls.Add(label7, 0, 0);
            tableLayoutPanel22.Controls.Add(salarybox, 1, 1);
            tableLayoutPanel22.Dock = DockStyle.Fill;
            tableLayoutPanel22.Location = new Point(3, 3);
            tableLayoutPanel22.Name = "tableLayoutPanel22";
            tableLayoutPanel22.RowCount = 2;
            tableLayoutPanel22.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel22.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel22.Size = new Size(594, 228);
            tableLayoutPanel22.TabIndex = 0;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(3, 155);
            label8.Name = "label8";
            label8.Size = new Size(291, 32);
            label8.TabIndex = 3;
            label8.Text = "Salary Amount";
            // 
            // teacherIdbox
            // 
            teacherIdbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            teacherIdbox.BackColor = Color.Transparent;
            teacherIdbox.CustomizableEdges = customizableEdges43;
            teacherIdbox.DrawMode = DrawMode.OwnerDrawFixed;
            teacherIdbox.DropDownStyle = ComboBoxStyle.DropDownList;
            teacherIdbox.FocusedColor = Color.FromArgb(94, 148, 255);
            teacherIdbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            teacherIdbox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            teacherIdbox.ForeColor = Color.FromArgb(68, 88, 112);
            teacherIdbox.ItemHeight = 30;
            teacherIdbox.Location = new Point(300, 39);
            teacherIdbox.Name = "teacherIdbox";
            teacherIdbox.ShadowDecoration.CustomizableEdges = customizableEdges44;
            teacherIdbox.Size = new Size(291, 36);
            teacherIdbox.TabIndex = 0;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(3, 41);
            label7.Name = "label7";
            label7.Size = new Size(291, 32);
            label7.TabIndex = 1;
            label7.Text = "Teacher ID";
            // 
            // salarybox
            // 
            salarybox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            salarybox.CustomizableEdges = customizableEdges45;
            salarybox.DefaultText = "";
            salarybox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            salarybox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            salarybox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            salarybox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            salarybox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            salarybox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            salarybox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            salarybox.Location = new Point(300, 144);
            salarybox.Name = "salarybox";
            salarybox.PasswordChar = '\0';
            salarybox.PlaceholderText = "";
            salarybox.SelectedText = "";
            salarybox.ShadowDecoration.CustomizableEdges = customizableEdges46;
            salarybox.Size = new Size(291, 54);
            salarybox.TabIndex = 2;
            salarybox.Validating += salarybox_Validating;
            // 
            // tableLayoutPanel23
            // 
            tableLayoutPanel23.ColumnCount = 2;
            tableLayoutPanel23.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel23.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel23.Controls.Add(salarydate, 1, 0);
            tableLayoutPanel23.Controls.Add(label9, 0, 0);
            tableLayoutPanel23.Dock = DockStyle.Fill;
            tableLayoutPanel23.Location = new Point(603, 3);
            tableLayoutPanel23.Name = "tableLayoutPanel23";
            tableLayoutPanel23.RowCount = 2;
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel23.Size = new Size(594, 228);
            tableLayoutPanel23.TabIndex = 1;
            // 
            // salarydate
            // 
            salarydate.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            salarydate.Checked = true;
            salarydate.CustomizableEdges = customizableEdges47;
            salarydate.FillColor = Color.FromArgb(224, 224, 224);
            salarydate.Font = new Font("Times New Roman", 10F, FontStyle.Bold, GraphicsUnit.Point);
            salarydate.Format = DateTimePickerFormat.Long;
            salarydate.Location = new Point(300, 30);
            salarydate.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            salarydate.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            salarydate.Name = "salarydate";
            salarydate.ShadowDecoration.CustomizableEdges = customizableEdges48;
            salarydate.Size = new Size(291, 54);
            salarydate.TabIndex = 0;
            salarydate.Value = new DateTime(2023, 11, 27, 20, 17, 15, 588);
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(3, 41);
            label9.Name = "label9";
            label9.Size = new Size(291, 32);
            label9.TabIndex = 1;
            label9.Text = "Date";
            // 
            // tableLayoutPanel24
            // 
            tableLayoutPanel24.ColumnCount = 1;
            tableLayoutPanel24.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel24.Controls.Add(tableLayoutPanel25, 0, 0);
            tableLayoutPanel24.Controls.Add(addedSalaryGV, 0, 1);
            tableLayoutPanel24.Dock = DockStyle.Fill;
            tableLayoutPanel24.Location = new Point(3, 458);
            tableLayoutPanel24.Name = "tableLayoutPanel24";
            tableLayoutPanel24.RowCount = 2;
            tableLayoutPanel24.RowStyles.Add(new RowStyle(SizeType.Percent, 35.81662F));
            tableLayoutPanel24.RowStyles.Add(new RowStyle(SizeType.Percent, 64.18338F));
            tableLayoutPanel24.Size = new Size(1206, 349);
            tableLayoutPanel24.TabIndex = 2;
            // 
            // tableLayoutPanel25
            // 
            tableLayoutPanel25.ColumnCount = 4;
            tableLayoutPanel25.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.Controls.Add(addsbutton, 0, 0);
            tableLayoutPanel25.Controls.Add(viewsalarybutton, 1, 0);
            tableLayoutPanel25.Controls.Add(updatesalarybutton, 2, 0);
            tableLayoutPanel25.Dock = DockStyle.Fill;
            tableLayoutPanel25.Location = new Point(3, 3);
            tableLayoutPanel25.Name = "tableLayoutPanel25";
            tableLayoutPanel25.RowCount = 1;
            tableLayoutPanel25.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel25.Size = new Size(1200, 119);
            tableLayoutPanel25.TabIndex = 0;
            // 
            // addsbutton
            // 
            addsbutton.BackColor = Color.FromArgb(128, 255, 128);
            addsbutton.Dock = DockStyle.Fill;
            addsbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            addsbutton.ForeColor = Color.White;
            addsbutton.Location = new Point(3, 3);
            addsbutton.Name = "addsbutton";
            addsbutton.Size = new Size(294, 113);
            addsbutton.TabIndex = 0;
            addsbutton.Text = "Add Salary";
            addsbutton.UseVisualStyleBackColor = false;
            addsbutton.Click += addsbutton_Click;
            // 
            // viewsalarybutton
            // 
            viewsalarybutton.BackColor = Color.FromArgb(128, 255, 128);
            viewsalarybutton.Dock = DockStyle.Fill;
            viewsalarybutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            viewsalarybutton.ForeColor = Color.White;
            viewsalarybutton.Location = new Point(303, 3);
            viewsalarybutton.Name = "viewsalarybutton";
            viewsalarybutton.Size = new Size(294, 113);
            viewsalarybutton.TabIndex = 1;
            viewsalarybutton.Text = "View Details";
            viewsalarybutton.UseVisualStyleBackColor = false;
            viewsalarybutton.Click += viewsalarybutton_Click;
            // 
            // updatesalarybutton
            // 
            updatesalarybutton.BackColor = Color.FromArgb(128, 255, 128);
            updatesalarybutton.Dock = DockStyle.Fill;
            updatesalarybutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            updatesalarybutton.ForeColor = Color.White;
            updatesalarybutton.Location = new Point(603, 3);
            updatesalarybutton.Name = "updatesalarybutton";
            updatesalarybutton.Size = new Size(294, 113);
            updatesalarybutton.TabIndex = 2;
            updatesalarybutton.Text = "Update Details";
            updatesalarybutton.UseVisualStyleBackColor = false;
            updatesalarybutton.Click += updatesalarybutton_Click;
            // 
            // addedSalaryGV
            // 
            addedSalaryGV.AllowUserToAddRows = false;
            addedSalaryGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            addedSalaryGV.Dock = DockStyle.Fill;
            addedSalaryGV.Location = new Point(3, 128);
            addedSalaryGV.Name = "addedSalaryGV";
            addedSalaryGV.RowHeadersWidth = 62;
            addedSalaryGV.RowTemplate.Height = 33;
            addedSalaryGV.Size = new Size(1200, 218);
            addedSalaryGV.TabIndex = 1;
            // 
            // chattab
            // 
            chattab.Controls.Add(chat_tab);
            chattab.Location = new Point(184, 4);
            chattab.Name = "chattab";
            chattab.Size = new Size(1212, 810);
            chattab.TabIndex = 7;
            chattab.Text = "Chat";
            chattab.UseVisualStyleBackColor = true;
            // 
            // chat_tab
            // 
            chat_tab.Alignment = TabAlignment.Left;
            chat_tab.Controls.Add(tabPage4);
            chat_tab.Controls.Add(tabPage5);
            chat_tab.Dock = DockStyle.Fill;
            chat_tab.ItemSize = new Size(180, 40);
            chat_tab.Location = new Point(0, 0);
            chat_tab.Name = "chat_tab";
            chat_tab.Padding = new Point(6, 6);
            chat_tab.SelectedIndex = 0;
            chat_tab.Size = new Size(1212, 810);
            chat_tab.TabButtonHoverState.BorderColor = Color.Empty;
            chat_tab.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            chat_tab.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            chat_tab.TabButtonHoverState.ForeColor = Color.White;
            chat_tab.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            chat_tab.TabButtonIdleState.BorderColor = Color.Empty;
            chat_tab.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            chat_tab.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            chat_tab.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            chat_tab.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            chat_tab.TabButtonSelectedState.BorderColor = Color.Empty;
            chat_tab.TabButtonSelectedState.FillColor = Color.FromArgb(29, 37, 49);
            chat_tab.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            chat_tab.TabButtonSelectedState.ForeColor = Color.White;
            chat_tab.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            chat_tab.TabButtonSize = new Size(180, 40);
            chat_tab.TabIndex = 0;
            chat_tab.TabMenuBackColor = Color.FromArgb(224, 224, 224);
            chat_tab.SelectedIndexChanged += chat_tab_SelectedIndexChanged;
            // 
            // tabPage4
            // 
            tabPage4.BorderStyle = BorderStyle.FixedSingle;
            tabPage4.Controls.Add(tableLayoutPanel26);
            tabPage4.Location = new Point(184, 4);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(1024, 802);
            tabPage4.TabIndex = 0;
            tabPage4.Text = "Sent Chat to Student";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel26
            // 
            tableLayoutPanel26.ColumnCount = 1;
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel26.Controls.Add(studentmessageGV, 0, 0);
            tableLayoutPanel26.Controls.Add(tableLayoutPanel27, 0, 1);
            tableLayoutPanel26.Dock = DockStyle.Fill;
            tableLayoutPanel26.Location = new Point(3, 3);
            tableLayoutPanel26.Name = "tableLayoutPanel26";
            tableLayoutPanel26.RowCount = 2;
            tableLayoutPanel26.RowStyles.Add(new RowStyle(SizeType.Percent, 30.8564224F));
            tableLayoutPanel26.RowStyles.Add(new RowStyle(SizeType.Percent, 69.14358F));
            tableLayoutPanel26.Size = new Size(1016, 794);
            tableLayoutPanel26.TabIndex = 0;
            // 
            // studentmessageGV
            // 
            studentmessageGV.AllowUserToAddRows = false;
            studentmessageGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            studentmessageGV.Dock = DockStyle.Fill;
            studentmessageGV.Location = new Point(3, 3);
            studentmessageGV.Name = "studentmessageGV";
            studentmessageGV.RowHeadersWidth = 62;
            studentmessageGV.RowTemplate.Height = 33;
            studentmessageGV.Size = new Size(1010, 239);
            studentmessageGV.TabIndex = 0;
            // 
            // tableLayoutPanel27
            // 
            tableLayoutPanel27.ColumnCount = 1;
            tableLayoutPanel27.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel27.Controls.Add(tableLayoutPanel28, 0, 0);
            tableLayoutPanel27.Controls.Add(textBox1, 0, 1);
            tableLayoutPanel27.Dock = DockStyle.Fill;
            tableLayoutPanel27.Location = new Point(3, 248);
            tableLayoutPanel27.Name = "tableLayoutPanel27";
            tableLayoutPanel27.RowCount = 2;
            tableLayoutPanel27.RowStyles.Add(new RowStyle(SizeType.Percent, 41.6206245F));
            tableLayoutPanel27.RowStyles.Add(new RowStyle(SizeType.Percent, 58.3793755F));
            tableLayoutPanel27.Size = new Size(1010, 543);
            tableLayoutPanel27.TabIndex = 1;
            // 
            // tableLayoutPanel28
            // 
            tableLayoutPanel28.ColumnCount = 2;
            tableLayoutPanel28.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel28.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel28.Controls.Add(tableLayoutPanel29, 0, 0);
            tableLayoutPanel28.Controls.Add(tableLayoutPanel30, 0, 1);
            tableLayoutPanel28.Controls.Add(tableLayoutPanel31, 1, 0);
            tableLayoutPanel28.Dock = DockStyle.Fill;
            tableLayoutPanel28.Location = new Point(3, 3);
            tableLayoutPanel28.Name = "tableLayoutPanel28";
            tableLayoutPanel28.RowCount = 2;
            tableLayoutPanel28.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel28.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel28.Size = new Size(1004, 220);
            tableLayoutPanel28.TabIndex = 0;
            // 
            // tableLayoutPanel29
            // 
            tableLayoutPanel29.ColumnCount = 2;
            tableLayoutPanel29.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel29.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel29.Controls.Add(studentmsgId, 1, 0);
            tableLayoutPanel29.Controls.Add(guna2HtmlLabel8, 0, 0);
            tableLayoutPanel29.Dock = DockStyle.Fill;
            tableLayoutPanel29.Location = new Point(3, 3);
            tableLayoutPanel29.Name = "tableLayoutPanel29";
            tableLayoutPanel29.RowCount = 1;
            tableLayoutPanel29.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel29.Size = new Size(496, 104);
            tableLayoutPanel29.TabIndex = 0;
            // 
            // studentmsgId
            // 
            studentmsgId.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            studentmsgId.BackColor = Color.Transparent;
            studentmsgId.CustomizableEdges = customizableEdges49;
            studentmsgId.DrawMode = DrawMode.OwnerDrawFixed;
            studentmsgId.DropDownStyle = ComboBoxStyle.DropDownList;
            studentmsgId.FocusedColor = Color.FromArgb(94, 148, 255);
            studentmsgId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            studentmsgId.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            studentmsgId.ForeColor = Color.FromArgb(68, 88, 112);
            studentmsgId.ItemHeight = 30;
            studentmsgId.Location = new Point(251, 34);
            studentmsgId.Name = "studentmsgId";
            studentmsgId.ShadowDecoration.CustomizableEdges = customizableEdges50;
            studentmsgId.Size = new Size(242, 36);
            studentmsgId.TabIndex = 0;
            // 
            // guna2HtmlLabel8
            // 
            guna2HtmlLabel8.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel8.BackColor = Color.Transparent;
            guna2HtmlLabel8.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel8.Location = new Point(3, 35);
            guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            guna2HtmlLabel8.Size = new Size(130, 34);
            guna2HtmlLabel8.TabIndex = 1;
            guna2HtmlLabel8.Text = "Student Id";
            // 
            // tableLayoutPanel30
            // 
            tableLayoutPanel30.ColumnCount = 2;
            tableLayoutPanel30.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel30.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel30.Controls.Add(guna2HtmlLabel9, 0, 0);
            tableLayoutPanel30.Controls.Add(sendmsgbox, 1, 0);
            tableLayoutPanel30.Dock = DockStyle.Fill;
            tableLayoutPanel30.Location = new Point(3, 113);
            tableLayoutPanel30.Name = "tableLayoutPanel30";
            tableLayoutPanel30.RowCount = 1;
            tableLayoutPanel30.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel30.Size = new Size(496, 104);
            tableLayoutPanel30.TabIndex = 1;
            // 
            // guna2HtmlLabel9
            // 
            guna2HtmlLabel9.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel9.BackColor = Color.Transparent;
            guna2HtmlLabel9.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel9.Location = new Point(3, 35);
            guna2HtmlLabel9.Name = "guna2HtmlLabel9";
            guna2HtmlLabel9.Size = new Size(103, 34);
            guna2HtmlLabel9.TabIndex = 2;
            guna2HtmlLabel9.Text = "Message";
            // 
            // sendmsgbox
            // 
            sendmsgbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            sendmsgbox.CustomizableEdges = customizableEdges51;
            sendmsgbox.DefaultText = "";
            sendmsgbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            sendmsgbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            sendmsgbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            sendmsgbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            sendmsgbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            sendmsgbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            sendmsgbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            sendmsgbox.Location = new Point(251, 25);
            sendmsgbox.Name = "sendmsgbox";
            sendmsgbox.PasswordChar = '\0';
            sendmsgbox.PlaceholderText = "Message";
            sendmsgbox.SelectedText = "";
            sendmsgbox.ShadowDecoration.CustomizableEdges = customizableEdges52;
            sendmsgbox.Size = new Size(242, 54);
            sendmsgbox.TabIndex = 0;
            // 
            // tableLayoutPanel31
            // 
            tableLayoutPanel31.ColumnCount = 2;
            tableLayoutPanel31.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel31.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel31.Controls.Add(sendmsgbutton, 0, 0);
            tableLayoutPanel31.Controls.Add(viewmsgbutton, 1, 0);
            tableLayoutPanel31.Dock = DockStyle.Fill;
            tableLayoutPanel31.Location = new Point(505, 3);
            tableLayoutPanel31.Name = "tableLayoutPanel31";
            tableLayoutPanel31.RowCount = 2;
            tableLayoutPanel31.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel31.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel31.Size = new Size(496, 104);
            tableLayoutPanel31.TabIndex = 2;
            // 
            // sendmsgbutton
            // 
            sendmsgbutton.BackColor = Color.FromArgb(128, 255, 128);
            sendmsgbutton.Dock = DockStyle.Fill;
            sendmsgbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            sendmsgbutton.ForeColor = Color.White;
            sendmsgbutton.Location = new Point(3, 3);
            sendmsgbutton.Name = "sendmsgbutton";
            sendmsgbutton.Size = new Size(242, 46);
            sendmsgbutton.TabIndex = 0;
            sendmsgbutton.Text = "Send Message";
            sendmsgbutton.UseVisualStyleBackColor = false;
            sendmsgbutton.Click += sendmsgbutton_Click;
            // 
            // viewmsgbutton
            // 
            viewmsgbutton.BackColor = Color.FromArgb(128, 255, 128);
            viewmsgbutton.Dock = DockStyle.Fill;
            viewmsgbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            viewmsgbutton.ForeColor = Color.White;
            viewmsgbutton.Location = new Point(251, 3);
            viewmsgbutton.Name = "viewmsgbutton";
            viewmsgbutton.Size = new Size(242, 46);
            viewmsgbutton.TabIndex = 1;
            viewmsgbutton.Text = "View Messages";
            viewmsgbutton.UseVisualStyleBackColor = false;
            viewmsgbutton.Click += viewmsgbutton_Click;
            // 
            // textBox1
            // 
            textBox1.Dock = DockStyle.Fill;
            textBox1.Location = new Point(3, 229);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(1004, 311);
            textBox1.TabIndex = 1;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(tableLayoutPanel32);
            tabPage5.Location = new Point(184, 4);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1024, 802);
            tabPage5.TabIndex = 1;
            tabPage5.Text = "Chat with Teacher";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel32
            // 
            tableLayoutPanel32.ColumnCount = 1;
            tableLayoutPanel32.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel32.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel32.Controls.Add(teacherchatGV, 0, 0);
            tableLayoutPanel32.Controls.Add(tableLayoutPanel33, 0, 1);
            tableLayoutPanel32.Dock = DockStyle.Fill;
            tableLayoutPanel32.Location = new Point(3, 3);
            tableLayoutPanel32.Name = "tableLayoutPanel32";
            tableLayoutPanel32.RowCount = 2;
            tableLayoutPanel32.RowStyles.Add(new RowStyle(SizeType.Percent, 33.9195976F));
            tableLayoutPanel32.RowStyles.Add(new RowStyle(SizeType.Percent, 66.0804F));
            tableLayoutPanel32.Size = new Size(1018, 796);
            tableLayoutPanel32.TabIndex = 0;
            // 
            // teacherchatGV
            // 
            teacherchatGV.AllowUserToAddRows = false;
            teacherchatGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            teacherchatGV.BorderStyle = BorderStyle.Fixed3D;
            teacherchatGV.CellBorderStyle = DataGridViewCellBorderStyle.SingleVertical;
            teacherchatGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            teacherchatGV.Dock = DockStyle.Fill;
            teacherchatGV.Location = new Point(3, 3);
            teacherchatGV.Name = "teacherchatGV";
            teacherchatGV.RowHeadersWidth = 62;
            teacherchatGV.RowTemplate.Height = 33;
            teacherchatGV.Size = new Size(1012, 264);
            teacherchatGV.TabIndex = 0;
            // 
            // tableLayoutPanel33
            // 
            tableLayoutPanel33.ColumnCount = 1;
            tableLayoutPanel33.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel33.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel33.Controls.Add(tableLayoutPanel34, 0, 0);
            tableLayoutPanel33.Controls.Add(teachermsgBox, 0, 1);
            tableLayoutPanel33.Dock = DockStyle.Fill;
            tableLayoutPanel33.Location = new Point(3, 273);
            tableLayoutPanel33.Name = "tableLayoutPanel33";
            tableLayoutPanel33.RowCount = 2;
            tableLayoutPanel33.RowStyles.Add(new RowStyle(SizeType.Percent, 44.6153831F));
            tableLayoutPanel33.RowStyles.Add(new RowStyle(SizeType.Percent, 55.3846169F));
            tableLayoutPanel33.Size = new Size(1012, 520);
            tableLayoutPanel33.TabIndex = 1;
            // 
            // tableLayoutPanel34
            // 
            tableLayoutPanel34.ColumnCount = 2;
            tableLayoutPanel34.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel34.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel34.Controls.Add(tableLayoutPanel35, 0, 0);
            tableLayoutPanel34.Controls.Add(tableLayoutPanel36, 0, 1);
            tableLayoutPanel34.Controls.Add(tableLayoutPanel37, 1, 0);
            tableLayoutPanel34.Dock = DockStyle.Fill;
            tableLayoutPanel34.Location = new Point(3, 3);
            tableLayoutPanel34.Name = "tableLayoutPanel34";
            tableLayoutPanel34.RowCount = 2;
            tableLayoutPanel34.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel34.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel34.Size = new Size(1006, 226);
            tableLayoutPanel34.TabIndex = 0;
            // 
            // tableLayoutPanel35
            // 
            tableLayoutPanel35.ColumnCount = 2;
            tableLayoutPanel35.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel35.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel35.Controls.Add(teacherboxId, 1, 0);
            tableLayoutPanel35.Controls.Add(guna2HtmlLabel10, 0, 0);
            tableLayoutPanel35.Dock = DockStyle.Fill;
            tableLayoutPanel35.Location = new Point(3, 3);
            tableLayoutPanel35.Name = "tableLayoutPanel35";
            tableLayoutPanel35.RowCount = 1;
            tableLayoutPanel35.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel35.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel35.Size = new Size(497, 107);
            tableLayoutPanel35.TabIndex = 0;
            // 
            // teacherboxId
            // 
            teacherboxId.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            teacherboxId.BackColor = Color.Transparent;
            teacherboxId.CustomizableEdges = customizableEdges53;
            teacherboxId.DrawMode = DrawMode.OwnerDrawFixed;
            teacherboxId.DropDownStyle = ComboBoxStyle.DropDownList;
            teacherboxId.FocusedColor = Color.FromArgb(94, 148, 255);
            teacherboxId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            teacherboxId.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            teacherboxId.ForeColor = Color.FromArgb(68, 88, 112);
            teacherboxId.ItemHeight = 30;
            teacherboxId.Location = new Point(251, 35);
            teacherboxId.Name = "teacherboxId";
            teacherboxId.ShadowDecoration.CustomizableEdges = customizableEdges54;
            teacherboxId.Size = new Size(243, 36);
            teacherboxId.TabIndex = 0;
            // 
            // guna2HtmlLabel10
            // 
            guna2HtmlLabel10.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel10.BackColor = Color.FromArgb(224, 224, 224);
            guna2HtmlLabel10.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel10.Location = new Point(3, 36);
            guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            guna2HtmlLabel10.Size = new Size(132, 34);
            guna2HtmlLabel10.TabIndex = 1;
            guna2HtmlLabel10.Text = "Teacher Id";
            // 
            // tableLayoutPanel36
            // 
            tableLayoutPanel36.ColumnCount = 2;
            tableLayoutPanel36.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel36.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel36.Controls.Add(messageteacher, 1, 0);
            tableLayoutPanel36.Controls.Add(guna2HtmlLabel11, 0, 0);
            tableLayoutPanel36.Dock = DockStyle.Fill;
            tableLayoutPanel36.Location = new Point(3, 116);
            tableLayoutPanel36.Name = "tableLayoutPanel36";
            tableLayoutPanel36.RowCount = 1;
            tableLayoutPanel36.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel36.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel36.Size = new Size(497, 107);
            tableLayoutPanel36.TabIndex = 1;
            // 
            // messageteacher
            // 
            messageteacher.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            messageteacher.CustomizableEdges = customizableEdges55;
            messageteacher.DefaultText = "";
            messageteacher.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            messageteacher.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            messageteacher.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            messageteacher.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            messageteacher.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            messageteacher.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            messageteacher.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            messageteacher.Location = new Point(251, 26);
            messageteacher.Name = "messageteacher";
            messageteacher.PasswordChar = '\0';
            messageteacher.PlaceholderText = "Write Message";
            messageteacher.SelectedText = "";
            messageteacher.ShadowDecoration.CustomizableEdges = customizableEdges56;
            messageteacher.Size = new Size(243, 54);
            messageteacher.TabIndex = 0;
            // 
            // guna2HtmlLabel11
            // 
            guna2HtmlLabel11.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            guna2HtmlLabel11.BackColor = Color.FromArgb(224, 224, 224);
            guna2HtmlLabel11.Font = new Font("Times New Roman", 16F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel11.Location = new Point(3, 34);
            guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            guna2HtmlLabel11.Size = new Size(118, 38);
            guna2HtmlLabel11.TabIndex = 1;
            guna2HtmlLabel11.Text = "Message";
            // 
            // tableLayoutPanel37
            // 
            tableLayoutPanel37.ColumnCount = 2;
            tableLayoutPanel37.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel37.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel37.Controls.Add(sendtmsgbutton, 0, 0);
            tableLayoutPanel37.Controls.Add(viewtbutton, 1, 0);
            tableLayoutPanel37.Dock = DockStyle.Fill;
            tableLayoutPanel37.Location = new Point(506, 3);
            tableLayoutPanel37.Name = "tableLayoutPanel37";
            tableLayoutPanel37.RowCount = 2;
            tableLayoutPanel37.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel37.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel37.Size = new Size(497, 107);
            tableLayoutPanel37.TabIndex = 2;
            // 
            // sendtmsgbutton
            // 
            sendtmsgbutton.BackColor = Color.FromArgb(128, 255, 128);
            sendtmsgbutton.Dock = DockStyle.Fill;
            sendtmsgbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            sendtmsgbutton.Location = new Point(3, 3);
            sendtmsgbutton.Name = "sendtmsgbutton";
            sendtmsgbutton.Size = new Size(242, 47);
            sendtmsgbutton.TabIndex = 0;
            sendtmsgbutton.Text = "Send Message";
            sendtmsgbutton.UseVisualStyleBackColor = false;
            sendtmsgbutton.Click += sendtmsgbutton_Click;
            // 
            // viewtbutton
            // 
            viewtbutton.BackColor = Color.FromArgb(128, 255, 128);
            viewtbutton.Dock = DockStyle.Fill;
            viewtbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            viewtbutton.Location = new Point(251, 3);
            viewtbutton.Name = "viewtbutton";
            viewtbutton.Size = new Size(243, 47);
            viewtbutton.TabIndex = 1;
            viewtbutton.Text = "View Message";
            viewtbutton.UseVisualStyleBackColor = false;
            viewtbutton.Click += viewtbutton_Click;
            // 
            // teachermsgBox
            // 
            teachermsgBox.Dock = DockStyle.Fill;
            teachermsgBox.Location = new Point(3, 235);
            teachermsgBox.Multiline = true;
            teachermsgBox.Name = "teachermsgBox";
            teachermsgBox.Size = new Size(1006, 282);
            teachermsgBox.TabIndex = 1;
            // 
            // tabPage6
            // 
            tabPage6.Location = new Point(184, 4);
            tabPage6.Name = "tabPage6";
            tabPage6.Size = new Size(1212, 810);
            tabPage6.TabIndex = 8;
            tabPage6.Text = "Log Out";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // Admin
            // 
            AllowDrop = true;
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(add_student);
            Name = "Admin";
            Size = new Size(1400, 818);
            tabPage2.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)teacherGV).EndInit();
            tableLayoutPanel7.ResumeLayout(false);
            add_student.ResumeLayout(false);
            tabPage3.ResumeLayout(false);
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            Profile_View.ResumeLayout(false);
            Profile_View.PerformLayout();
            tabPage1.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)studentGV).EndInit();
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            coursetab.ResumeLayout(false);
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel10.ResumeLayout(false);
            tableLayoutPanel10.PerformLayout();
            tableLayoutPanel11.ResumeLayout(false);
            tableLayoutPanel12.ResumeLayout(false);
            tableLayoutPanel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)courseGV).EndInit();
            feetab.ResumeLayout(false);
            tableLayoutPanel13.ResumeLayout(false);
            tableLayoutPanel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)feestudentGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)feeCourseGV).EndInit();
            tableLayoutPanel15.ResumeLayout(false);
            tableLayoutPanel15.PerformLayout();
            tableLayoutPanel16.ResumeLayout(false);
            tableLayoutPanel16.PerformLayout();
            tableLayoutPanel17.ResumeLayout(false);
            tableLayoutPanel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)feeGV).EndInit();
            salarytab.ResumeLayout(false);
            tableLayoutPanel19.ResumeLayout(false);
            tableLayoutPanel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)teachersalaryGV).EndInit();
            tableLayoutPanel21.ResumeLayout(false);
            tableLayoutPanel22.ResumeLayout(false);
            tableLayoutPanel22.PerformLayout();
            tableLayoutPanel23.ResumeLayout(false);
            tableLayoutPanel23.PerformLayout();
            tableLayoutPanel24.ResumeLayout(false);
            tableLayoutPanel25.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)addedSalaryGV).EndInit();
            chattab.ResumeLayout(false);
            chat_tab.ResumeLayout(false);
            tabPage4.ResumeLayout(false);
            tableLayoutPanel26.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)studentmessageGV).EndInit();
            tableLayoutPanel27.ResumeLayout(false);
            tableLayoutPanel27.PerformLayout();
            tableLayoutPanel28.ResumeLayout(false);
            tableLayoutPanel29.ResumeLayout(false);
            tableLayoutPanel29.PerformLayout();
            tableLayoutPanel30.ResumeLayout(false);
            tableLayoutPanel30.PerformLayout();
            tableLayoutPanel31.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            tableLayoutPanel32.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)teacherchatGV).EndInit();
            tableLayoutPanel33.ResumeLayout(false);
            tableLayoutPanel33.PerformLayout();
            tableLayoutPanel34.ResumeLayout(false);
            tableLayoutPanel35.ResumeLayout(false);
            tableLayoutPanel35.PerformLayout();
            tableLayoutPanel36.ResumeLayout(false);
            tableLayoutPanel36.PerformLayout();
            tableLayoutPanel37.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabPage2;
        private TableLayoutPanel tableLayoutPanel4;
        private DataGridView teacherGV;
        private Guna.UI2.WinForms.Guna2TabControl add_student;
        private TabPage Profile_View;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TileButton updatebutton;
        private Guna.UI2.WinForms.Guna2TextBox phonenumberbox;
        private Guna.UI2.WinForms.Guna2TextBox username;
        private Guna.UI2.WinForms.Guna2TextBox emailBox;
        private Guna.UI2.WinForms.Guna2TextBox password;
        private Guna.UI2.WinForms.Guna2TextBox name;
        private TabPage tabPage1;
        private TableLayoutPanel tableLayoutPanel1;
        public Guna.UI2.WinForms.Guna2DataGridView studentGV;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private Guna.UI2.WinForms.Guna2Button addbutton;
        private Guna.UI2.WinForms.Guna2Button deleteButton;
        private Guna.UI2.WinForms.Guna2Button allstudentbutton;
        private Guna.UI2.WinForms.Guna2Button update_Button;
        private TabPage tabPage3;
        private TableLayoutPanel tableLayoutPanel5;
        private TableLayoutPanel tableLayoutPanel6;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private TableLayoutPanel tableLayoutPanel7;
        private Guna.UI2.WinForms.Guna2Button update_button1;
        private Guna.UI2.WinForms.Guna2Button view_button;
        private Guna.UI2.WinForms.Guna2Button add_button;
        private Guna.UI2.WinForms.Guna2Button delete_button;
        private TabPage coursetab;
        private TableLayoutPanel tableLayoutPanel8;
        private TableLayoutPanel tableLayoutPanel9;
        private TableLayoutPanel tableLayoutPanel10;
        private Guna.UI2.WinForms.Guna2TextBox nametext;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel11;
        private Guna.UI2.WinForms.Guna2Button add_course;
        private Button viewbutton;
        private DataGridView courseGV;
        private Button deletebtn;
        private Button updatecoursebutton;
        private TableLayoutPanel tableLayoutPanel12;
        private Guna.UI2.WinForms.Guna2ComboBox activeStatus;
        private Label label2;
        private Button vew_inbutton;
        private TabPage feetab;
        private TableLayoutPanel tableLayoutPanel13;
        private TableLayoutPanel tableLayoutPanel14;
        private DataGridView feestudentGV;
        private DataGridView feeCourseGV;
        private TableLayoutPanel tableLayoutPanel15;
        private Label label3;
        private TableLayoutPanel tableLayoutPanel16;
        private Label label4;
        private Guna.UI2.WinForms.Guna2ComboBox courseIdbox;
        private Guna.UI2.WinForms.Guna2ComboBox studentIdbox;
        private Guna.UI2.WinForms.Guna2TextBox amountbox;
        private Label label5;
        private Guna.UI2.WinForms.Guna2DateTimePicker DateTimePicker1;
        private Label label6;
        private TableLayoutPanel tableLayoutPanel17;
        private TableLayoutPanel tableLayoutPanel18;
        private Button feebutton;
        private Button view_feebutton;
        private DataGridView feeGV;
        private Button updatefeebutton;
        private TabPage salarytab;
        private TableLayoutPanel tableLayoutPanel19;
        private TableLayoutPanel tableLayoutPanel20;
        private DataGridView teachersalaryGV;
        private TableLayoutPanel tableLayoutPanel21;
        private TableLayoutPanel tableLayoutPanel22;
        private TableLayoutPanel tableLayoutPanel23;
        private Label label8;
        private Guna.UI2.WinForms.Guna2ComboBox teacherIdbox;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox salarybox;
        private Guna.UI2.WinForms.Guna2DateTimePicker salarydate;
        private Label label9;
        private TableLayoutPanel tableLayoutPanel24;
        private TableLayoutPanel tableLayoutPanel25;
        private Button addsbutton;
        private Button viewsalarybutton;
        private DataGridView addedSalaryGV;
        private Button updatesalarybutton;
        private TabPage chattab;
        private Guna.UI2.WinForms.Guna2TabControl chat_tab;
        private TabPage tabPage4;
        private TabPage tabPage5;
        private TableLayoutPanel tableLayoutPanel26;
        private DataGridView studentmessageGV;
        private TableLayoutPanel tableLayoutPanel27;
        private TableLayoutPanel tableLayoutPanel28;
        private TableLayoutPanel tableLayoutPanel29;
        private Guna.UI2.WinForms.Guna2ComboBox studentmsgId;
        private TableLayoutPanel tableLayoutPanel30;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel9;
        private Guna.UI2.WinForms.Guna2TextBox sendmsgbox;
        private TableLayoutPanel tableLayoutPanel31;
        private Button sendmsgbutton;
        private TextBox textBox1;
        private Button viewmsgbutton;
        private TableLayoutPanel tableLayoutPanel32;
        private DataGridView teacherchatGV;
        private TableLayoutPanel tableLayoutPanel33;
        private TableLayoutPanel tableLayoutPanel34;
        private TableLayoutPanel tableLayoutPanel35;
        private TableLayoutPanel tableLayoutPanel36;
        private TableLayoutPanel tableLayoutPanel37;
        private Guna.UI2.WinForms.Guna2ComboBox teacherboxId;
        private TextBox teachermsgBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2TextBox messageteacher;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Button sendtmsgbutton;
        private Button viewtbutton;
        private TabPage tabPage6;
    }
}
