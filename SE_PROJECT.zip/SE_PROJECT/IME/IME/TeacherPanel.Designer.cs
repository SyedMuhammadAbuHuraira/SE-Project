﻿namespace IME
{
    partial class TeacherPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2TabControl1 = new Guna.UI2.WinForms.Guna2TabControl();
            courseMTab = new TabPage();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            tableLayoutPanel4 = new TableLayoutPanel();
            cmIdbox = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            label1 = new Label();
            studentidbox = new Guna.UI2.WinForms.Guna2ComboBox();
            tableLayoutPanel5 = new TableLayoutPanel();
            markbox = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            tableLayoutPanel6 = new TableLayoutPanel();
            button1 = new Button();
            viewbutton = new Button();
            button2 = new Button();
            cmGV = new DataGridView();
            courseTab = new TabPage();
            tableLayoutPanel7 = new TableLayoutPanel();
            tableLayoutPanel8 = new TableLayoutPanel();
            tableLayoutPanel9 = new TableLayoutPanel();
            tableLayoutPanel10 = new TableLayoutPanel();
            courseId = new Guna.UI2.WinForms.Guna2ComboBox();
            label3 = new Label();
            matrialbox = new TextBox();
            label4 = new Label();
            tableLayoutPanel11 = new TableLayoutPanel();
            tableLayoutPanel12 = new TableLayoutPanel();
            addbutton = new Button();
            button3 = new Button();
            button4 = new Button();
            matrialGV = new DataGridView();
            logouttab = new TabPage();
            guna2TabControl1.SuspendLayout();
            courseMTab.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)cmGV).BeginInit();
            courseTab.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            tableLayoutPanel10.SuspendLayout();
            tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)matrialGV).BeginInit();
            SuspendLayout();
            // 
            // guna2TabControl1
            // 
            guna2TabControl1.Alignment = TabAlignment.Left;
            guna2TabControl1.Controls.Add(courseMTab);
            guna2TabControl1.Controls.Add(courseTab);
            guna2TabControl1.Controls.Add(logouttab);
            guna2TabControl1.Dock = DockStyle.Fill;
            guna2TabControl1.ItemSize = new Size(180, 40);
            guna2TabControl1.Location = new Point(0, 0);
            guna2TabControl1.Name = "guna2TabControl1";
            guna2TabControl1.SelectedIndex = 0;
            guna2TabControl1.Size = new Size(1174, 725);
            guna2TabControl1.TabButtonHoverState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            guna2TabControl1.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonHoverState.ForeColor = Color.White;
            guna2TabControl1.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            guna2TabControl1.TabButtonIdleState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            guna2TabControl1.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.TabButtonSelectedState.BorderColor = Color.Empty;
            guna2TabControl1.TabButtonSelectedState.FillColor = Color.FromArgb(29, 37, 49);
            guna2TabControl1.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TabControl1.TabButtonSelectedState.ForeColor = Color.White;
            guna2TabControl1.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            guna2TabControl1.TabButtonSize = new Size(180, 40);
            guna2TabControl1.TabIndex = 0;
            guna2TabControl1.TabMenuBackColor = Color.FromArgb(33, 42, 57);
            guna2TabControl1.SelectedIndexChanged += guna2TabControl1_SelectedIndexChanged;
            // 
            // courseMTab
            // 
            courseMTab.Controls.Add(tableLayoutPanel1);
            courseMTab.Location = new Point(184, 4);
            courseMTab.Name = "courseMTab";
            courseMTab.Padding = new Padding(3);
            courseMTab.Size = new Size(986, 717);
            courseMTab.TabIndex = 0;
            courseMTab.Text = "Course Marks";
            courseMTab.UseVisualStyleBackColor = true;
            courseMTab.Click += courseMTab_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 0);
            tableLayoutPanel1.Controls.Add(cmGV, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(3, 3);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(980, 711);
            tableLayoutPanel1.TabIndex = 0;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 0, 0);
            tableLayoutPanel2.Controls.Add(tableLayoutPanel6, 0, 1);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 3);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 71.3467F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 28.6532955F));
            tableLayoutPanel2.Size = new Size(974, 349);
            tableLayoutPanel2.TabIndex = 0;
            tableLayoutPanel2.Paint += tableLayoutPanel2_Paint;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 51.136364F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48.863636F));
            tableLayoutPanel3.Controls.Add(tableLayoutPanel4, 0, 0);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel5, 1, 0);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 3);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 2;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Size = new Size(968, 243);
            tableLayoutPanel3.TabIndex = 0;
            tableLayoutPanel3.Paint += tableLayoutPanel3_Paint;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 2;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Controls.Add(cmIdbox, 1, 0);
            tableLayoutPanel4.Controls.Add(guna2HtmlLabel1, 0, 0);
            tableLayoutPanel4.Controls.Add(label1, 0, 1);
            tableLayoutPanel4.Controls.Add(studentidbox, 1, 1);
            tableLayoutPanel4.Dock = DockStyle.Fill;
            tableLayoutPanel4.Location = new Point(3, 3);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 2;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel4.Size = new Size(489, 115);
            tableLayoutPanel4.TabIndex = 0;
            tableLayoutPanel4.Paint += tableLayoutPanel4_Paint;
            // 
            // cmIdbox
            // 
            cmIdbox.BackColor = Color.Transparent;
            cmIdbox.CustomizableEdges = customizableEdges1;
            cmIdbox.Dock = DockStyle.Fill;
            cmIdbox.DrawMode = DrawMode.OwnerDrawFixed;
            cmIdbox.DropDownStyle = ComboBoxStyle.DropDownList;
            cmIdbox.FocusedColor = Color.FromArgb(94, 148, 255);
            cmIdbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cmIdbox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cmIdbox.ForeColor = Color.FromArgb(68, 88, 112);
            cmIdbox.ItemHeight = 30;
            cmIdbox.Location = new Point(247, 3);
            cmIdbox.Name = "cmIdbox";
            cmIdbox.ShadowDecoration.CustomizableEdges = customizableEdges2;
            cmIdbox.Size = new Size(239, 36);
            cmIdbox.TabIndex = 0;
            cmIdbox.SelectedIndexChanged += cmIdbox_SelectedIndexChanged;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            guna2HtmlLabel1.Location = new Point(3, 3);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(121, 34);
            guna2HtmlLabel1.TabIndex = 1;
            guna2HtmlLabel1.Text = "Course Id";
            guna2HtmlLabel1.Click += guna2HtmlLabel1_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(3, 70);
            label1.Name = "label1";
            label1.Size = new Size(238, 32);
            label1.TabIndex = 2;
            label1.Text = "Student ID";
            label1.Click += label1_Click;
            // 
            // studentidbox
            // 
            studentidbox.BackColor = Color.Transparent;
            studentidbox.CustomizableEdges = customizableEdges3;
            studentidbox.Dock = DockStyle.Fill;
            studentidbox.DrawMode = DrawMode.OwnerDrawFixed;
            studentidbox.DropDownStyle = ComboBoxStyle.DropDownList;
            studentidbox.FocusedColor = Color.FromArgb(94, 148, 255);
            studentidbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            studentidbox.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            studentidbox.ForeColor = Color.FromArgb(68, 88, 112);
            studentidbox.ItemHeight = 30;
            studentidbox.Location = new Point(247, 60);
            studentidbox.Name = "studentidbox";
            studentidbox.ShadowDecoration.CustomizableEdges = customizableEdges4;
            studentidbox.Size = new Size(239, 36);
            studentidbox.TabIndex = 3;
            studentidbox.SelectedIndexChanged += studentidbox_SelectedIndexChanged;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 2;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Controls.Add(markbox, 1, 0);
            tableLayoutPanel5.Controls.Add(label2, 0, 0);
            tableLayoutPanel5.Dock = DockStyle.Fill;
            tableLayoutPanel5.Location = new Point(498, 3);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 2;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Size = new Size(467, 115);
            tableLayoutPanel5.TabIndex = 1;
            tableLayoutPanel5.Paint += tableLayoutPanel5_Paint;
            // 
            // markbox
            // 
            markbox.CustomizableEdges = customizableEdges5;
            markbox.DefaultText = "";
            markbox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            markbox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            markbox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            markbox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            markbox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            markbox.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            markbox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            markbox.Location = new Point(236, 3);
            markbox.Name = "markbox";
            markbox.PasswordChar = '\0';
            markbox.PlaceholderText = "Marks";
            markbox.SelectedText = "";
            markbox.ShadowDecoration.CustomizableEdges = customizableEdges6;
            markbox.Size = new Size(228, 51);
            markbox.TabIndex = 0;
            markbox.TextChanged += markbox_TextChanged;
            markbox.Validating += markbox_Validating;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(3, 12);
            label2.Name = "label2";
            label2.Size = new Size(227, 32);
            label2.TabIndex = 1;
            label2.Text = "Student Marks";
            label2.Click += label2_Click;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 4;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.Controls.Add(button1, 0, 0);
            tableLayoutPanel6.Controls.Add(viewbutton, 1, 0);
            tableLayoutPanel6.Controls.Add(button2, 2, 0);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(3, 252);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel6.Size = new Size(968, 94);
            tableLayoutPanel6.TabIndex = 1;
            tableLayoutPanel6.Paint += tableLayoutPanel6_Paint;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(128, 255, 128);
            button1.Dock = DockStyle.Fill;
            button1.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(3, 3);
            button1.Name = "button1";
            button1.Size = new Size(236, 88);
            button1.TabIndex = 0;
            button1.Text = "Add Marks";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // viewbutton
            // 
            viewbutton.BackColor = Color.FromArgb(128, 255, 128);
            viewbutton.Dock = DockStyle.Fill;
            viewbutton.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            viewbutton.ForeColor = SystemColors.ButtonHighlight;
            viewbutton.Location = new Point(245, 3);
            viewbutton.Name = "viewbutton";
            viewbutton.Size = new Size(236, 88);
            viewbutton.TabIndex = 1;
            viewbutton.Text = "View Marks";
            viewbutton.UseVisualStyleBackColor = false;
            viewbutton.Click += viewbutton_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(128, 255, 128);
            button2.Dock = DockStyle.Fill;
            button2.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(487, 3);
            button2.Name = "button2";
            button2.Size = new Size(236, 88);
            button2.TabIndex = 2;
            button2.Text = "Update Marks";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // cmGV
            // 
            cmGV.AllowUserToAddRows = false;
            cmGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            cmGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            cmGV.Dock = DockStyle.Fill;
            cmGV.Location = new Point(3, 358);
            cmGV.Name = "cmGV";
            cmGV.RowHeadersWidth = 62;
            cmGV.RowTemplate.Height = 33;
            cmGV.Size = new Size(974, 350);
            cmGV.TabIndex = 1;
            // 
            // courseTab
            // 
            courseTab.Controls.Add(tableLayoutPanel7);
            courseTab.Location = new Point(184, 4);
            courseTab.Name = "courseTab";
            courseTab.Padding = new Padding(3);
            courseTab.Size = new Size(986, 717);
            courseTab.TabIndex = 1;
            courseTab.Text = "Course Matrial";
            courseTab.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 1;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Controls.Add(tableLayoutPanel8, 0, 0);
            tableLayoutPanel7.Controls.Add(matrialGV, 0, 1);
            tableLayoutPanel7.Dock = DockStyle.Fill;
            tableLayoutPanel7.Location = new Point(3, 3);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 2;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel7.Size = new Size(980, 711);
            tableLayoutPanel7.TabIndex = 0;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 1;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel8.Controls.Add(tableLayoutPanel9, 0, 0);
            tableLayoutPanel8.Controls.Add(tableLayoutPanel12, 0, 1);
            tableLayoutPanel8.Dock = DockStyle.Fill;
            tableLayoutPanel8.Location = new Point(3, 3);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 2;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 75.07163F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 24.9283676F));
            tableLayoutPanel8.Size = new Size(974, 349);
            tableLayoutPanel8.TabIndex = 0;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.ColumnCount = 2;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Controls.Add(tableLayoutPanel10, 0, 0);
            tableLayoutPanel9.Controls.Add(tableLayoutPanel11, 1, 0);
            tableLayoutPanel9.Dock = DockStyle.Fill;
            tableLayoutPanel9.Location = new Point(3, 3);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 2;
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel9.Size = new Size(968, 256);
            tableLayoutPanel9.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.ColumnCount = 2;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.Controls.Add(courseId, 1, 0);
            tableLayoutPanel10.Controls.Add(label3, 0, 0);
            tableLayoutPanel10.Controls.Add(matrialbox, 1, 1);
            tableLayoutPanel10.Controls.Add(label4, 0, 1);
            tableLayoutPanel10.Dock = DockStyle.Fill;
            tableLayoutPanel10.Location = new Point(3, 3);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 2;
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel10.Size = new Size(478, 122);
            tableLayoutPanel10.TabIndex = 0;
            // 
            // courseId
            // 
            courseId.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            courseId.BackColor = Color.Transparent;
            courseId.CustomizableEdges = customizableEdges7;
            courseId.DrawMode = DrawMode.OwnerDrawFixed;
            courseId.DropDownStyle = ComboBoxStyle.DropDownList;
            courseId.FocusedColor = Color.FromArgb(94, 148, 255);
            courseId.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            courseId.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            courseId.ForeColor = Color.FromArgb(68, 88, 112);
            courseId.ItemHeight = 30;
            courseId.Location = new Point(242, 12);
            courseId.Name = "courseId";
            courseId.ShadowDecoration.CustomizableEdges = customizableEdges8;
            courseId.Size = new Size(233, 36);
            courseId.TabIndex = 0;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(3, 14);
            label3.Name = "label3";
            label3.Size = new Size(233, 32);
            label3.TabIndex = 1;
            label3.Text = "Course_ID";
            // 
            // matrialbox
            // 
            matrialbox.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            matrialbox.Location = new Point(242, 76);
            matrialbox.Name = "matrialbox";
            matrialbox.Size = new Size(233, 31);
            matrialbox.TabIndex = 2;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(3, 75);
            label4.Name = "label4";
            label4.Size = new Size(233, 32);
            label4.TabIndex = 3;
            label4.Text = "Matrial ";
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.ColumnCount = 2;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.Dock = DockStyle.Fill;
            tableLayoutPanel11.Location = new Point(487, 3);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 2;
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel11.Size = new Size(478, 122);
            tableLayoutPanel11.TabIndex = 1;
            // 
            // tableLayoutPanel12
            // 
            tableLayoutPanel12.ColumnCount = 4;
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.Controls.Add(addbutton, 0, 0);
            tableLayoutPanel12.Controls.Add(button3, 1, 0);
            tableLayoutPanel12.Controls.Add(button4, 2, 0);
            tableLayoutPanel12.Dock = DockStyle.Fill;
            tableLayoutPanel12.Location = new Point(3, 265);
            tableLayoutPanel12.Name = "tableLayoutPanel12";
            tableLayoutPanel12.RowCount = 1;
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel12.Size = new Size(968, 81);
            tableLayoutPanel12.TabIndex = 1;
            // 
            // addbutton
            // 
            addbutton.BackColor = Color.FromArgb(128, 255, 128);
            addbutton.Dock = DockStyle.Fill;
            addbutton.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
            addbutton.ForeColor = Color.White;
            addbutton.Location = new Point(3, 3);
            addbutton.Name = "addbutton";
            addbutton.Size = new Size(236, 75);
            addbutton.TabIndex = 0;
            addbutton.Text = "Add Matrial";
            addbutton.UseVisualStyleBackColor = false;
            addbutton.Click += addbutton_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(128, 255, 128);
            button3.Dock = DockStyle.Fill;
            button3.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            button3.ForeColor = Color.White;
            button3.Location = new Point(245, 3);
            button3.Name = "button3";
            button3.Size = new Size(236, 75);
            button3.TabIndex = 1;
            button3.Text = "View Matrial";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(128, 255, 128);
            button4.Dock = DockStyle.Fill;
            button4.Font = new Font("Times New Roman", 14F, FontStyle.Bold, GraphicsUnit.Point);
            button4.ForeColor = Color.White;
            button4.Location = new Point(487, 3);
            button4.Name = "button4";
            button4.Size = new Size(236, 75);
            button4.TabIndex = 2;
            button4.Text = "Update Matrial";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // matrialGV
            // 
            matrialGV.AllowUserToAddRows = false;
            matrialGV.BackgroundColor = Color.FromArgb(224, 224, 224);
            matrialGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            matrialGV.Dock = DockStyle.Fill;
            matrialGV.Location = new Point(3, 358);
            matrialGV.Name = "matrialGV";
            matrialGV.RowHeadersWidth = 62;
            matrialGV.RowTemplate.Height = 33;
            matrialGV.Size = new Size(974, 350);
            matrialGV.TabIndex = 1;
            // 
            // logouttab
            // 
            logouttab.Location = new Point(184, 4);
            logouttab.Name = "logouttab";
            logouttab.Size = new Size(986, 717);
            logouttab.TabIndex = 2;
            logouttab.Text = "Log out";
            logouttab.UseVisualStyleBackColor = true;
            // 
            // TeacherPanel
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(guna2TabControl1);
            Name = "TeacherPanel";
            Size = new Size(1174, 725);
            guna2TabControl1.ResumeLayout(false);
            courseMTab.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            tableLayoutPanel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)cmGV).EndInit();
            courseTab.ResumeLayout(false);
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel10.ResumeLayout(false);
            tableLayoutPanel10.PerformLayout();
            tableLayoutPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)matrialGV).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TabControl guna2TabControl1;
        private TabPage courseMTab;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel4;
        private Guna.UI2.WinForms.Guna2ComboBox cmIdbox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox studentidbox;
        private TableLayoutPanel tableLayoutPanel5;
        private Guna.UI2.WinForms.Guna2TextBox markbox;
        private Label label2;
        private TableLayoutPanel tableLayoutPanel6;
        private Button button1;
        private Button viewbutton;
        private DataGridView cmGV;
        private Button button2;
        private TabPage courseTab;
        private TableLayoutPanel tableLayoutPanel7;
        private TableLayoutPanel tableLayoutPanel8;
        private TableLayoutPanel tableLayoutPanel9;
        private TableLayoutPanel tableLayoutPanel10;
        private TableLayoutPanel tableLayoutPanel11;
        private Guna.UI2.WinForms.Guna2ComboBox courseId;
        private Label label3;
        private TextBox matrialbox;
        private Label label4;
        private TableLayoutPanel tableLayoutPanel12;
        private Button addbutton;
        private DataGridView matrialGV;
        private Button button3;
        private Button button4;
        private TabPage logouttab;
    }
}
